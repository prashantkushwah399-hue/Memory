package com.memoir.ai

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.memoir.ai.ai.*
import com.memoir.ai.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AppVM(app: Application) : AndroidViewModel(app) {
    val repo = (app as MemoirApp).repo
    private val ctx: Application get() = getApplication<Application>()
    private val prefs = app.getSharedPreferences("settings", 0)
    val engine: LlmEngine = EngineProvider.create()
    private val chat = ChatEngine(repo, engine) { template }

    var template by mutableStateOf(prefs.getString("template", "chatml")!!)
    var autoSave by mutableStateOf(prefs.getBoolean("autosave", true))
    var messages by mutableStateOf(listOf<Message>())
    var streaming by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var pending by mutableStateOf(listOf<Candidate>())
    var journal by mutableStateOf(listOf<Journal>())
    var goals by mutableStateOf(listOf<Goal>())
    var version by mutableIntStateOf(0)
    var toast by mutableStateOf<String?>(null)
    var modelStatus by mutableStateOf("Model load nahi hua — offline memory mode")
    var downloading by mutableStateOf<String?>(null)
    var progress by mutableFloatStateOf(0f)
    var models by mutableStateOf(listOf<File>())
    var loadedPath by mutableStateOf<String?>(null)
    var loading by mutableStateOf(false)
    var ramInfo by mutableStateOf("")

    init {
        viewModelScope.launch {
            refresh(); models = ModelStore.list(ctx)
            ramInfo = ModelStore.ramLine(ctx)
            val saved = prefs.getString("model_path", null)?.takeIf { File(it).exists() }
            if (prefs.getBoolean("load_in_progress", false)) {
                // The app died while loading a model last time (almost certainly out of RAM): don't crash-loop.
                prefs.edit().remove("model_path").putBoolean("load_in_progress", false).commit()
                toast = "Pichli baar model load ke dauraan app band ho gaya (RAM kam). Auto-load band; chhota model choose karo."
            } else if (saved != null) loadModel(saved)
        }
    }

    suspend fun refresh() {
        messages = repo.dao.messages().takeLast(1000); journal = repo.dao.journal(); goals = repo.dao.goals(); version++
    }
    private fun guard(block: suspend () -> Unit) = viewModelScope.launch {
        try { block() } catch (e: Exception) { toast = "Error: ${e.message}" }
    }

    // ---- chat ----
    fun send(text: String) {
        if (busy) return
        if (loading) { toast = "Model load ho raha hai, thoda ruko…"; return }
        busy = true
        viewModelScope.launch {
            try {
                streaming = ""
                val t = chat.respond(text, autoSave, onUser = { messages = repo.dao.messages().takeLast(1000) }) { streaming = (streaming ?: "") + it }
                pending = pending + t.pending
                t.error?.let { toast = "AI error: $it" }
            } catch (e: Exception) { toast = "Error: ${e.message}" }
            finally { streaming = null; busy = false; refresh() }
        }
    }
    fun ask(text: String) = send(text)
    fun approve(c: Candidate) = guard {
        pending = pending - c
        repo.logJournal(c.text)
        toast = if (repo.saveCandidate(c.copy(importance = maxOf(3, c.importance))) == Outcome.DUPLICATE) "Pehle se saved hai" else "Save ho gaya"
        refresh()
    }
    fun dismiss(c: Candidate) { pending = pending - c }

    // ---- memories ----
    suspend fun queryMemories(q: String, cat: String?, showOld: Boolean): List<Memory> {
        if (q.isBlank()) return repo.allMemories().filter { (showOld || it.status == "active") && (cat == null || it.category == cat) }
        val hits = repo.search(q, 40, TimeParse.range(q), cat ?: Extractor.categoryHint(q), withThread = false).map { it.m }
        return if (showOld) hits else hits.filter { it.status == "active" }
    }
    fun addMemory(text: String, cat: String) = guard {
        toast = if (repo.saveCandidate(Candidate(text, cat, 4, false)) == Outcome.DUPLICATE) "Pehle se saved hai" else "Memory saved"; refresh() }
    fun editMemory(m: Memory, text: String, cat: String) = guard { repo.editMemory(m, text, cat); refresh() }
    fun deleteMemory(m: Memory) = guard { repo.deleteMemory(m.id); refresh() }
    fun setStatus(m: Memory, s: String) = guard { repo.setStatus(m, s); refresh() }

    fun loadThread(id: Long, cb: (List<Memory>) -> Unit) { viewModelScope.launch { cb(repo.thread(id)) } }

    // ---- journal ----
    fun saveJournal(id: Long, day: String, text: String, auto: Boolean) = guard {
        repo.dao.saveJournal(Journal(id, day, Secret(text), auto, System.currentTimeMillis())); refresh() }
    fun deleteJournal(j: Journal) = guard { repo.dao.deleteJournal(j.id); refresh() }

    // ---- goals ----
    fun saveGoal(g: Goal) = guard { repo.dao.saveGoal(g.copy(updatedAt = System.currentTimeMillis(), done = g.done || g.progress >= 100)); refresh() }
    fun addGoal(title: String, isTask: Boolean) { val n = System.currentTimeMillis(); saveGoal(Goal(title = Secret(title), isTask = isTask, createdAt = n, updatedAt = n)) }
    fun deleteGoal(g: Goal) = guard { repo.dao.deleteGoal(g.id); refresh() }

    // ---- models ----
    fun loadModel(path: String) = viewModelScope.launch {
        if (loading) return@launch
        val f = File(path)
        val ram = ModelStore.ramCheck(ctx, f)
        if (!ram.ok) { toast = ram.msg; return@launch }
        ram.msg?.let { toast = it }
        loading = true
        modelStatus = "Model load ho raha hai… (${f.name})"
        prefs.edit().putBoolean("load_in_progress", true).commit()      // crash-loop guard, cleared below
        val r = try { withContext(Dispatchers.IO) { engine.load(path) } } finally { loading = false }
        prefs.edit().putBoolean("load_in_progress", false).commit()
        if (r.isSuccess) {
            prefs.edit().putString("model_path", path).apply()
            loadedPath = path
            modelStatus = "Model: ${f.name} · ctx ${engine.contextSize}"
            toast = "Model ready — ab chat mein baat karo"
        } else {
            loadedPath = null
            modelStatus = "Model load nahi hua — offline memory mode"
            toast = r.exceptionOrNull()?.message
        }
        ramInfo = ModelStore.ramLine(ctx)
    }
    fun unloadModel() = guard {
        engine.unload(); loadedPath = null; prefs.edit().remove("model_path").apply()
        modelStatus = "Model load nahi hua — offline memory mode"; ramInfo = ModelStore.ramLine(ctx)
    }
    fun updateTemplate(t: String) { template = t; prefs.edit().putString("template", t).apply() }
    fun updateAutoSave(b: Boolean) { autoSave = b; prefs.edit().putBoolean("autosave", b).apply() }
    fun download(p: Preset) {
        if (downloading != null) return
        downloading = p.name; progress = 0f
        viewModelScope.launch {
            try {
                val f = ModelStore.download(ctx, p) { progress = it }
                updateTemplate(p.template); models = ModelStore.list(ctx); loadModel(f.absolutePath)
            } catch (e: Exception) { toast = "Download fail: ${e.message}" } finally { downloading = null }
        }
    }
    fun importModel(uri: Uri) = guard {
        val f = withContext(Dispatchers.IO) { ModelStore.copyFrom(ctx, uri) }
        models = ModelStore.list(ctx); loadModel(f.absolutePath)
    }
    fun deleteModel(f: File) = guard {
        if (loadedPath == f.absolutePath) { engine.unload(); loadedPath = null; prefs.edit().remove("model_path").apply(); modelStatus = "Model load nahi hua — offline memory mode" }
        f.delete(); models = ModelStore.list(ctx)
    }

    // ---- backup ----
    private val cr get() = ctx.contentResolver
    fun exportBackup(uri: Uri, pass: String) = guard {
        val bytes = withContext(Dispatchers.Default) { Crypto.sealWithPass(repo.exportJson().toByteArray(), pass.toCharArray()) }
        withContext(Dispatchers.IO) { cr.openOutputStream(uri)!!.use { it.write(bytes) } }
        toast = "Encrypted backup ban gaya"
    }
    fun importBackup(uri: Uri, pass: String) = viewModelScope.launch {
        try {
            val bytes = withContext(Dispatchers.IO) { cr.openInputStream(uri)!!.use { it.readBytes() } }
            val json = withContext(Dispatchers.Default) { String(Crypto.openWithPass(bytes, pass.toCharArray())) }
            repo.importJson(json); refresh(); toast = "Backup restore ho gaya"
        } catch (e: javax.crypto.AEADBadTagException) { toast = "Passphrase galat hai ya file corrupt hai"
        } catch (e: Exception) { toast = "Restore fail: ${e.message}" }
    }
    fun exportMarkdown(uri: Uri) = guard {
        val s = repo.exportMarkdown(); withContext(Dispatchers.IO) { cr.openOutputStream(uri)!!.use { it.write(s.toByteArray()) } }; toast = "Markdown export ho gaya (unencrypted)" }
    fun wipe() = guard { repo.wipe(); pending = emptyList(); refresh(); toast = "Sab data delete ho gaya" }
}
