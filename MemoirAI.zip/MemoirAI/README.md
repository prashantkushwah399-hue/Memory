# Memoir AI — private, on-device Personal Memory + Life Manager (Android)

Kotlin · Jetpack Compose · Room/SQLite · AES-256-GCM (Android Keystore) · llama.cpp (optional GGUF) · 100% offline

## Architecture
```
 UI (Compose, dark)  Chat | Memories | Journal+Insights | Goals | Settings
        │
     AppVM (single ViewModel, state holder)
        │
 ChatEngine ── per message:
   1 retrieve (hybrid semantic+keyword+time filter, thread expansion)   ← BEFORE saving, so it can't retrieve itself
   2 extract candidates (Extractor, rule-based, Hinglish-aware)
        sensitive → "pending" card, saved ONLY after user taps Yes
        normal    → journal line + memory (importance ≥3) with dedupe/link/supersede
   3 reply: LLM (llama.cpp) with YAAD-section grounding  — or deterministic offline reply
        memory-question with zero hits → fixed "mere paas save nahi hai" (LLM is bypassed: no invented memories)
        │
 Repo ── Room DB (memories, messages, journal, goals) ── Secret fields encrypted via Crypto
        └ in-RAM vector cache (256-d float / memory) for fast search
 Embedder: local hashed word+char-trigram+bigram vectors (no download, works on Hinglish)
 LlmEngine: interface → LlamaEngine (src/llama) | StubEngine (src/noLlama)
```
### Memory model
* **Categories**: Personal Life, Daily Activities, Goals, Projects, Ideas, Experiences, Preferences, Important Events.
* **Daily Activities** go to the Journal only (to avoid clutter) unless you say "yaad rakhna".
* **Dedupe**: same category & cosine ≥ 0.85 → no new row (timestamp/importance bumped).
* **Cross-conversation linking**: cosine ≥ 0.35 to an existing memory → same `threadId` (project history). "History" button shows the whole thread; retrieval pulls thread siblings into the prompt.
* **Outdated detection**: Preferences/Personal Life with cosine ≥ 0.50 to an older one → older marked `outdated` (never deleted; "Restore" button; thresholds in `Repo.companion`).
* **Time queries**: "last month / pichle mahine / this week / yesterday / last 7 din…" filter retrieval by date.
* **Insights**: stalled goals (14d), projects not mentioned (21d), ideas never followed up, recurring topics (≥3 memories), achievements/learning — every line is computed from saved data with counts/dates, no speculation.

### Privacy/security
* Memory text, embeddings, messages, journal, goals encrypted at rest (AES-256-GCM; data key wrapped by hardware-backed Keystore key).
* `allowBackup=false`; INTERNET permission only used by the optional model downloader.
* Backups: passphrase (PBKDF2-SHA256 120k) + AES-GCM. Markdown export is plain text (warned in UI).
* Updates keep data: Room versioned schema, **no destructive migration**. For schema changes add a `Migration` in `Repo`.
* Note: Keystore keys don't survive a factory reset/new phone → use in-app Backup/Restore to move devices.

## Build & run (works WITHOUT an LLM)
Requirements: Android Studio Koala (2024.1.1)+ or newer, JDK 17 (Studio's bundled JBR is fine), Android SDK Platform 34.
Pinned versions: Gradle 8.9 · AGP 8.5.2 · Kotlin 2.0.20 (+ Compose compiler plugin) · KSP 2.0.20-1.0.25 · Room 2.6.1 · Compose BOM 2024.09.00 · minSdk 26 / target+compile 34.

1. Open the `MemoirAI` folder in Android Studio and let Gradle sync (Studio downloads Gradle 8.9 from `gradle-wrapper.properties`; it creates `local.properties` with `sdk.dir` itself).
2. Run the `app` configuration, or from a terminal: `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
   `gradle/wrapper/gradle-wrapper.jar` is NOT bundled in this ZIP (binary file; could not be fetched offline). `gradlew`/`gradlew.bat` download it automatically once from
   `raw.githubusercontent.com/gradle/gradle/v8.9.0/...`; alternatively run `gradle wrapper --gradle-version 8.9` or just use Android Studio, which does not need the jar.
3. The native llama.cpp engine is built by default (see next section). Without a loaded model the app still works in offline-memory mode.

## On-device LLM (llama.cpp, built in)
Chain: `AppVM.loadModel` → `LlamaEngine` (Kotlin, `src/llama`) → `NativeLlama` (JNI) → `app/src/main/cpp/memoir_llm.cpp` → llama.cpp C API (static lib, built by CMake).
* **Build requirements:** Android NDK (AGP default, auto-installed) + CMake 3.22.1 (SDK Manager), `git` and internet **at build time only** (CMake fetches llama.cpp tag `b4800` once). Offline build: `-PllamaSrc=/path/to/llama.cpp`.
* **Gradle options** (`gradle.properties` or `-P`): `useLlama=false` (no native code), `llamaTag=bXXXX`, `llamaAbis=arm64-v8a,x86_64` (default arm64-v8a only), `llamaArch=armv8.2-a+dotprod` (faster, but SIGILL on old CPUs).
* **Native code always compiled with -O3**, even for debug builds (otherwise inference is unusably slow).
* **Models:** any GGUF whose architecture llama.cpp b4800 supports — Qwen2.5, Llama 3.2, Gemma 2 (presets in Settings, or Import .gguf). Pick the matching template chip: chatml = Qwen, llama3 = Llama 3.x, gemma = Gemma.
* **Load/switch/unload:** Settings → Load (previous model is freed first), "Unload model" frees RAM. Loading runs off the UI thread.
* **Streaming:** tokens are sampled (top-k 40, top-p 0.9, temp 0.7) and streamed to the chat bubble; UTF-8 characters split across tokens (Hindi/emoji) are re-assembled natively before crossing JNI.
* **Low-RAM handling:** pre-flight check refuses models > 80% of total RAM and warns when > 80% of free RAM; native side tries context 4096/2048 → 2048 → 1024 → 512 until allocation succeeds; prompts are shrunk (history, then memories) to fit the context; a "load in progress" flag prevents a crash-loop if Android kills the app during load.
* **Debug:** `adb logcat -s MemoirLLM` shows native load/context/errors.

## Honest limitations
* The native bridge targets the llama.cpp C API as of tag b4800 and was written WITHOUT being compiled or run (no NDK/network where it was authored). If a different `llamaTag` is used, API names in `memoir_llm.cpp` may need adjusting.
* Embeddings are lexical-hash vectors, not neural: great for same-word/transliteration overlap, weaker for pure paraphrase.
  Swap `Embedder.embed` for a GGUF embedding model for deeper semantics.
* Extraction is rule-based (predictable, never fabricates). Tune regexes in `Extractor.kt` for your speech patterns.
* Small LLMs (1–3B) can still err; the system prompt + zero-hit guard reduce, not eliminate, hallucination.
* Voice input uses Android's speech recognizer (offline only if the device has an offline language pack).
