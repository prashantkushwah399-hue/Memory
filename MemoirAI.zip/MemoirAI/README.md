# Memoir AI — private, on-device Personal Memory + Life Manager (Android)

Kotlin · Jetpack Compose · Room/SQLite · AES-256-GCM (Android Keystore) · llama.cpp (optional GGUF) · 100% offline

## Architecture
```
 UI (Compose, dark)  Chat | Memories | Journal+Insights | Goals | Settings
        │
     AppVM (single ViewModel, state holder)
        │
 ChatEngine ── per message:
   1 retrieve (hybrid semantic+keyword+time filter, thread expansion)   ← BEFORE saving, so it can't retrieve itself
   2 extract candidates (Extractor, rule-based, Hinglish-aware)
        sensitive → "pending" card, saved ONLY after user taps Yes
        normal    → journal line + memory (importance ≥3) with dedupe/link/supersede
   3 reply: LLM (llama.cpp) with YAAD-section grounding  — or deterministic offline reply
        memory-question with zero hits → fixed "mere paas save nahi hai" (LLM is bypassed: no invented memories)
        │
 Repo ── Room DB (memories, messages, journal, goals) ── Secret fields encrypted via Crypto
        └ in-RAM vector cache (256-d float / memory) for fast search
 Embedder: local hashed word+char-trigram+bigram vectors (no download, works on Hinglish)
 LlmEngine: interface → LlamaEngine (src/llama) | StubEngine (src/noLlama)
```
### Memory model
* **Categories**: Personal Life, Daily Activities, Goals, Projects, Ideas, Experiences, Preferences, Important Events.
* **Daily Activities** go to the Journal only (to avoid clutter) unless you say "yaad rakhna".
* **Dedupe**: same category & cosine ≥ 0.85 → no new row (timestamp/importance bumped).
* **Cross-conversation linking**: cosine ≥ 0.35 to an existing memory → same `threadId` (project history). "History" button shows the whole thread; retrieval pulls thread siblings into the prompt.
* **Outdated detection**: Preferences/Personal Life with cosine ≥ 0.50 to an older one → older marked `outdated` (never deleted; "Restore" button; thresholds in `Repo.companion`).
* **Time queries**: "last month / pichle mahine / this week / yesterday / last 7 din…" filter retrieval by date.
* **Insights**: stalled goals (14d), projects not mentioned (21d), ideas never followed up, recurring topics (≥3 memories), achievements/learning — every line is computed from saved data with counts/dates, no speculation.

### Privacy/security
* Memory text, embeddings, messages, journal, goals encrypted at rest (AES-256-GCM; data key wrapped by hardware-backed Keystore key).
* `allowBackup=false`; INTERNET permission only used by the optional model downloader.
* Backups: passphrase (PBKDF2-SHA256 120k) + AES-GCM. Markdown export is plain text (warned in UI).
* Updates keep data: Room versioned schema, **no destructive migration**. For schema changes add a `Migration` in `Repo`.
* Note: Keystore keys don't survive a factory reset/new phone → use in-app Backup/Restore to move devices.

## Build & run (works WITHOUT an LLM first)
1. Android Studio Koala (2024.1)+ , JDK 17, Android SDK 34. Open this folder → let Gradle sync
   (if no wrapper jar: run `gradle wrapper --gradle-version 8.9` once, or let Studio use its bundled Gradle).
2. Run on a device/emulator (minSdk 26). You get chat + auto memory + search + journal + goals + insights + backup in **offline memory mode**.

## Enable the on-device LLM (llama.cpp)
1. Android Studio → SDK Manager → install **NDK** and **CMake**.
2. `git clone https://github.com/ggerganov/llama.cpp`
3. Copy `llama.cpp/examples/llama.android/llama` into this project root as `MemoirAI/llama/`.
   Open `llama/src/main/cpp/CMakeLists.txt` and make sure the `add_subdirectory(...)` path points at your llama.cpp clone.
4. Build with the flag: add `useLlama=true` to `gradle.properties` (or `-PuseLlama=true`). Sync.
   The adapter `app/src/llama/.../EngineProvider.kt` targets `android.llama.cpp.LLamaAndroid` (`load/send/unload`);
   if your llama.cpp revision renamed these, edit only that file.
5. Settings → download a preset or **Import .gguf**. Pick the matching prompt template (chatml = Qwen, llama3 = Llama 3.x, gemma).
   Recommended: 4 GB RAM → Qwen2.5-1.5B / Llama-3.2-1B Q4; 6 GB+ → Qwen2.5-3B / Llama-3.2-3B Q4 (best Hinglish).
   Hugging Face links in `ModelStore.presets` are public GGUF files — verify they still exist; manual import always works.

## Honest limitations
* Written without a compiler available in the authoring environment: expect to fix small compile/API issues on first sync.
* Embeddings are lexical-hash vectors, not neural: great for same-word/transliteration overlap, weaker for pure paraphrase.
  Swap `Embedder.embed` for a GGUF embedding model for deeper semantics.
* Extraction is rule-based (predictable, never fabricates). Tune regexes in `Extractor.kt` for your speech patterns.
* Small LLMs (1–3B) can still err; the system prompt + zero-hit guard reduce, not eliminate, hallucination.
* Voice input uses Android's speech recognizer (offline only if the device has an offline language pack).
