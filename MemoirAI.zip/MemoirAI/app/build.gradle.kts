plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

// ---- on-device LLM (llama.cpp via NDK/CMake/JNI) is ON by default. Options (gradle.properties or -P):
//   -PuseLlama=false        build without native code (offline-memory mode only)
//   -PllamaTag=b4800        llama.cpp git tag fetched by CMake
//   -PllamaSrc=/path        use a local llama.cpp checkout instead of downloading (offline builds)
//   -PllamaAbis=arm64-v8a,x86_64   ABIs to build (default arm64-v8a)
//   -PllamaArch=armv8.2-a+dotprod  faster on newer phones; crashes (SIGILL) on old CPUs, so off by default
val useLlama = (project.findProperty("useLlama") as String?) != "false"
val llamaTag = (project.findProperty("llamaTag") as String?) ?: "b4800"
val llamaSrc = project.findProperty("llamaSrc") as String?
val llamaArch = project.findProperty("llamaArch") as String?
val llamaAbis = ((project.findProperty("llamaAbis") as String?) ?: "arm64-v8a").split(",").map { it.trim() }

android {
    namespace = "com.memoir.ai"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.memoir.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
        if (useLlama) {
            ndk { abiFilters += llamaAbis }
            externalNativeBuild {
                cmake {
                    arguments += listOf("-DANDROID_STL=c++_static", "-DLLAMA_CPP_TAG=$llamaTag")
                    if (llamaSrc != null) arguments += "-DLLAMA_CPP_SOURCE_DIR=$llamaSrc"
                    if (llamaArch != null) arguments += "-DLLAMA_ARM_ARCH=$llamaArch"
                }
            }
        }
    }
    if (useLlama) {
        externalNativeBuild {
            cmake {
                path = file("src/main/cpp/CMakeLists.txt")
                version = "3.22.1"
            }
        }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    sourceSets["main"].java.srcDir(if (useLlama) "src/llama/kotlin" else "src/noLlama/kotlin")
}
ksp { arg("room.schemaLocation", "$projectDir/schemas") }

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
