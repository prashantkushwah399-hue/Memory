package com.memoir.ai.ai

import android.llama.cpp.LLamaAndroid   // from llama.cpp/examples/llama.android (module ":llama")
import kotlinx.coroutines.flow.Flow

/** Adapter for llama.cpp's Android example binding. If your llama.cpp version changed the API, adjust here only. */
class LlamaEngine : LlmEngine {
    private val l = LLamaAndroid.instance()
    override var isLoaded = false
        private set
    override suspend fun load(path: String): Result<Unit> = runCatching { l.load(path); isLoaded = true; Unit }
    override fun generate(prompt: String): Flow<String> = l.send(prompt, formatChat = false)
    override suspend fun unload() { l.unload(); isLoaded = false }
}
object EngineProvider { fun create(): LlmEngine = LlamaEngine() }
