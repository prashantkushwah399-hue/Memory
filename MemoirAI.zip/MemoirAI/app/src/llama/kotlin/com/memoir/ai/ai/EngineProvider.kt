package com.memoir.ai.ai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/** Real on-device engine: llama.cpp through JNI. One model loaded at a time; load() replaces the previous one. */
class LlamaEngine : LlmEngine {
    private val lock = Mutex()
    @Volatile private var handle = 0L
    @Volatile private var ctx = 2048

    override val isLoaded: Boolean get() = handle != 0L
    override val contextSize: Int get() = ctx

    private fun threads(): Int = (Runtime.getRuntime().availableProcessors() - 2).coerceIn(2, 8)

    private fun friendly(t: Throwable): String = when (t) {
        is UnsatisfiedLinkError -> "Native library (libmemoir_llm.so) load nahi hui — is phone ka CPU/ABI supported nahi ya APK mein .so missing hai. (${t.message})"
        is OutOfMemoryError -> "RAM khatam ho gayi. Chhota model choose karo."
        else -> t.message ?: t.javaClass.simpleName
    }

    override suspend fun load(path: String): Result<Unit> {
        val h = handle
        if (h != 0L) NativeLlama.nCancel(h)           // stop any running generation before waiting for the lock
        return lock.withLock {
            withContext(Dispatchers.IO) {
                try {
                    freeLocked()
                    val sizeMb = File(path).length() / 1_000_000
                    val want = if (sizeMb <= 1200) 4096 else 2048
                    val nh = NativeLlama.nLoad(path.toByteArray(Charsets.UTF_8), want, threads())
                    handle = nh
                    ctx = NativeLlama.nContextSize(nh)
                    Result.success(Unit)
                } catch (c: CancellationException) { throw c
                } catch (t: Throwable) { Result.failure(Exception(friendly(t))) }
            }
        }
    }

    override fun generate(prompt: String): Flow<String> = callbackFlow {
        val h = handle
        if (h == 0L) { close(IllegalStateException("Model load nahi hai")); return@callbackFlow }
        val maxNew = minOf(512, ctx / 4)
        launch(Dispatchers.Default) {
            lock.withLock {
                try {
                    NativeLlama.nGenerate(h, prompt.toByteArray(Charsets.UTF_8), maxNew, 0.7f,
                        TokenCallback { bytes -> trySend(String(bytes, Charsets.UTF_8)).isSuccess && isActive })
                    close()
                } catch (t: Throwable) { close(Exception(friendly(t))) }
            }
        }
        awaitClose { NativeLlama.nCancel(h) }
    }.buffer(Channel.UNLIMITED)

    override suspend fun unload() {
        val h = handle
        if (h != 0L) NativeLlama.nCancel(h)
        lock.withLock { withContext(Dispatchers.IO) { freeLocked() } }
    }

    private fun freeLocked() {
        val h = handle
        handle = 0L
        if (h != 0L) NativeLlama.nFree(h)
    }
}

object EngineProvider { fun create(): LlmEngine = LlamaEngine() }
