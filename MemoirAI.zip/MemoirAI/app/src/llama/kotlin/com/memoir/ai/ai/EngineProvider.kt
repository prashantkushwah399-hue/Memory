package com.memoir.ai.ai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import android.os.Build
import android.util.Log
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/** Real on-device engine: llama.cpp through JNI. One model loaded at a time; load() replaces the previous one. */
class LlamaEngine : LlmEngine {
    private val lock = Mutex()
    @Volatile private var handle = 0L
    @Volatile private var ctx = 2048

    override val isLoaded: Boolean get() = handle != 0L
    override val contextSize: Int get() = ctx

    private fun threads(): Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 4)   // big.LITTLE: more threads than big cores = slower

    private fun friendly(t: Throwable): String = when (t) {
        is LinkageError -> "Native library (libmemoir_llm.so) load nahi hui. Phone ABI: ${Build.SUPPORTED_ABIS.joinToString()} — APK sirf arm64-v8a ke liye bana hai. (${t.message})"
        is OutOfMemoryError -> "RAM khatam ho gayi. Chhota model choose karo."
        else -> t.message ?: t.javaClass.simpleName
    }

    override suspend fun load(path: String): Result<Unit> {
        val h = handle
        if (h != 0L) NativeLlama.nCancel(h)           // stop any running generation before waiting for the lock
        return lock.withLock {
            withContext(Dispatchers.IO) {
                try {
                    freeLocked()
                    val sizeMb = File(path).length() / 1_000_000
                    val want = 2048   // small KV cache = less RAM, faster; ChatEngine shrinks the prompt to fit
                    val nh = NativeLlama.nLoad(path.toByteArray(Charsets.UTF_8), want, threads())
                    handle = nh
                    ctx = NativeLlama.nContextSize(nh)
                    Result.success(Unit)
                } catch (c: CancellationException) { throw c
                } catch (t: Throwable) { Result.failure(Exception(friendly(t))) }
            }
        }
    }

    override fun generate(prompt: String, progress: (Int, Int) -> Unit): Flow<String> = callbackFlow {
        val h = handle
        if (h == 0L) { close(IllegalStateException("Model load nahi hai")); return@callbackFlow }
        val maxNew = minOf(256, ctx / 4)
        val done = java.util.concurrent.atomic.AtomicBoolean(false)
        launch(Dispatchers.Default) {
            lock.withLock {
                try {
                    Log.i("MemoirLLM", "generate: prompt ${prompt.length} chars, ctx $ctx, maxNew $maxNew")
                    NativeLlama.nGenerate(h, prompt.toByteArray(Charsets.UTF_8), maxNew, 0.7f,
                        object : GenCallback {
                            override fun onToken(bytes: ByteArray): Boolean = trySend(String(bytes, Charsets.UTF_8)).isSuccess && isActive
                            override fun onProgress(done: Int, total: Int) { progress(done, total) }
                        })
                    done.set(true); close()
                } catch (t: Throwable) { Log.e("MemoirLLM", "generate failed", t); done.set(true); close(Exception(friendly(t))) }
            }
        }
        awaitClose { if (!done.get()) NativeLlama.nCancel(h) }
    }.buffer(Channel.UNLIMITED)

    override suspend fun unload() {
        val h = handle
        if (h != 0L) NativeLlama.nCancel(h)
        lock.withLock { withContext(Dispatchers.IO) { freeLocked() } }
    }

    private fun freeLocked() {
        val h = handle
        handle = 0L
        if (h != 0L) NativeLlama.nFree(h)
    }
}

object EngineProvider { fun create(): LlmEngine = LlamaEngine() }
