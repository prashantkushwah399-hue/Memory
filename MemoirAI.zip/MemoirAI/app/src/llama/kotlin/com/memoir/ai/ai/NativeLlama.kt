package com.memoir.ai.ai

/** Native -> Kotlin callbacks. onToken gets complete UTF-8 chunks (return false to stop); onProgress reports prompt prefill. */
interface GenCallback {
    fun onToken(bytes: ByteArray): Boolean
    fun onProgress(done: Int, total: Int)
}

/** JNI surface of libmemoir_llm.so (see app/src/main/cpp/memoir_llm.cpp). Errors are thrown as RuntimeException. */
object NativeLlama {
    init { System.loadLibrary("memoir_llm") }
    external fun nLoad(path: ByteArray, nCtx: Int, nThreads: Int): Long
    external fun nContextSize(handle: Long): Int
    external fun nGenerate(handle: Long, prompt: ByteArray, maxNew: Int, temp: Float, cb: GenCallback): Int
    external fun nCancel(handle: Long)
    external fun nFree(handle: Long)
    external fun nSystemInfo(): String
}
