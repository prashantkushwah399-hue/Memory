package com.memoir.ai.ai

/** Receives UTF-8 chunks (always complete characters). Return false to stop generation. */
fun interface TokenCallback { fun onToken(bytes: ByteArray): Boolean }

/** JNI surface of libmemoir_llm.so (see app/src/main/cpp/memoir_llm.cpp). Errors are thrown as RuntimeException. */
object NativeLlama {
    init { System.loadLibrary("memoir_llm") }
    external fun nLoad(path: ByteArray, nCtx: Int, nThreads: Int): Long
    external fun nContextSize(handle: Long): Int
    external fun nGenerate(handle: Long, prompt: ByteArray, maxNew: Int, temp: Float, cb: TokenCallback): Int
    external fun nCancel(handle: Long)
    external fun nFree(handle: Long)
    external fun nSystemInfo(): String
}
