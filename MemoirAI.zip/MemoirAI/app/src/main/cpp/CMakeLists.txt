cmake_minimum_required(VERSION 3.22.1)
project(memoir_llm LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# AGP builds the Debug variant with -O0, which makes llama.cpp unusably slow. Always optimise.
set(CMAKE_C_FLAGS_DEBUG   "-O3 -DNDEBUG" CACHE STRING "" FORCE)
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG" CACHE STRING "" FORCE)

# ---- llama.cpp (pinned tag, fetched at configure time; or use a local checkout) ----
set(LLAMA_CPP_TAG "b4800" CACHE STRING "llama.cpp git tag to build")
set(LLAMA_CPP_SOURCE_DIR "" CACHE PATH "Optional local llama.cpp checkout (offline builds)")
set(LLAMA_ARM_ARCH "" CACHE STRING "Optional ggml ARM arch, e.g. armv8.2-a+dotprod (faster, needs newer CPUs)")

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
if(LLAMA_ARM_ARCH)
    set(GGML_CPU_ARM_ARCH "${LLAMA_ARM_ARCH}" CACHE STRING "" FORCE)
endif()

if(LLAMA_CPP_SOURCE_DIR)
    add_subdirectory("${LLAMA_CPP_SOURCE_DIR}" "${CMAKE_BINARY_DIR}/llama.cpp" EXCLUDE_FROM_ALL)
else()
    include(FetchContent)
    FetchContent_Declare(llama_cpp
        GIT_REPOSITORY https://github.com/ggml-org/llama.cpp.git
        GIT_TAG ${LLAMA_CPP_TAG}
        GIT_SHALLOW TRUE)
    FetchContent_MakeAvailable(llama_cpp)
endif()

# ---- JNI bridge ----
add_library(memoir_llm SHARED memoir_llm.cpp)
target_link_libraries(memoir_llm PRIVATE llama android log)
# Android 15+ devices with 16 KB pages
target_link_options(memoir_llm PRIVATE "-Wl,-z,max-page-size=16384")
