// JNI bridge: Kotlin (com.memoir.ai.ai.NativeLlama)  <->  llama.cpp C API.
// Text crosses JNI as UTF-8 byte arrays (NewStringUTF is "modified UTF-8" and breaks on emoji / split chars).
#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>
#include "llama.h"

#define TAG "MemoirLLM"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

struct Engine {
    llama_model *model = nullptr;
    const llama_vocab *vocab = nullptr;
    int n_ctx = 2048;
    int n_threads = 4;
    std::atomic<bool> cancel{false};
    std::mutex gen_mu;
};

std::once_flag g_backend_once;
std::mutex g_err_mu;
std::string g_last_err;

void log_cb(ggml_log_level level, const char *text, void *) {
    if (level == GGML_LOG_LEVEL_ERROR) {
        LOGE("%s", text);
        std::lock_guard<std::mutex> lk(g_err_mu);
        g_last_err += text;
        if (g_last_err.size() > 600) g_last_err.erase(0, g_last_err.size() - 600);
    } else if (level == GGML_LOG_LEVEL_WARN) {
        __android_log_print(ANDROID_LOG_WARN, TAG, "%s", text);
    }
}

std::string take_last_err() {
    std::lock_guard<std::mutex> lk(g_err_mu);
    std::string s = g_last_err;
    g_last_err.clear();
    return s;
}

void throw_rt(JNIEnv *env, const std::string &msg) {
    jclass c = env->FindClass("java/lang/RuntimeException");
    if (c) env->ThrowNew(c, msg.c_str());
}

std::string to_str(JNIEnv *env, jbyteArray a) {
    if (!a) return {};
    jsize n = env->GetArrayLength(a);
    std::string s((size_t) n, '\0');
    if (n > 0) env->GetByteArrayRegion(a, 0, n, reinterpret_cast<jbyte *>(&s[0]));
    return s;
}

// Length of the longest prefix of s that does not end in the middle of a UTF-8 character.
size_t complete_utf8_len(const std::string &s) {
    size_t n = s.size();
    size_t i = n;
    for (int back = 0; i > 0 && back < 4; ++back) {
        unsigned char c = (unsigned char) s[i - 1];
        if ((c & 0xC0) == 0x80) { --i; continue; }           // continuation byte, keep walking back
        size_t need = c < 0x80 ? 1 : (c & 0xE0) == 0xC0 ? 2 : (c & 0xF0) == 0xE0 ? 3 : (c & 0xF8) == 0xF0 ? 4 : 1;
        size_t have = n - (i - 1);
        return have >= need ? n : i - 1;
    }
    return n;
}

bool emit(JNIEnv *env, jobject cb, jmethodID mid, const char *data, size_t len) {
    jbyteArray arr = env->NewByteArray((jsize) len);
    if (!arr) return false;
    env->SetByteArrayRegion(arr, 0, (jsize) len, reinterpret_cast<const jbyte *>(data));
    jboolean cont = env->CallBooleanMethod(cb, mid, arr);
    env->DeleteLocalRef(arr);
    if (env->ExceptionCheck()) { env->ExceptionClear(); return false; }
    return cont == JNI_TRUE;
}

llama_context *make_ctx(Engine *e, int n_ctx) {
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) n_ctx;
    cp.n_batch = 512;
    cp.n_ubatch = 512;
    cp.n_threads = e->n_threads;
    cp.n_threads_batch = e->n_threads;
    return llama_init_from_model(e->model, cp);
}

struct CtxGuard {
    llama_context *ctx = nullptr;
    llama_sampler *smpl = nullptr;
    ~CtxGuard() {
        if (smpl) llama_sampler_free(smpl);
        if (ctx) llama_free(ctx);
    }
};

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_memoir_ai_ai_NativeLlama_nLoad(JNIEnv *env, jobject, jbyteArray jpath, jint nCtx, jint nThreads) {
    Engine *e = nullptr;
    try {
        std::string path = to_str(env, jpath);
        FILE *f = fopen(path.c_str(), "rb");
        if (!f) { throw_rt(env, "Model file khul nahi rahi: " + path); return 0; }
        char magic[4] = {0};
        size_t r = fread(magic, 1, 4, f);
        fclose(f);
        if (r != 4 || memcmp(magic, "GGUF", 4) != 0) {
            throw_rt(env, "Ye valid GGUF file nahi hai (download adhura ya galat format ho sakta hai).");
            return 0;
        }

        std::call_once(g_backend_once, []() {
            llama_log_set(log_cb, nullptr);
            llama_backend_init();
        });
        take_last_err();

        llama_model_params mp = llama_model_default_params();
        mp.n_gpu_layers = 0;
        mp.use_mmap = true;   // pages are file-backed and can be evicted under memory pressure
        llama_model *model = llama_model_load_from_file(path.c_str(), mp);
        if (!model) {
            std::string why = take_last_err();
            throw_rt(env, "llama.cpp model load nahi kar paya (unsupported architecture, corrupt file ya RAM kam). " + why);
            return 0;
        }

        e = new Engine();
        e->model = model;
        e->vocab = llama_model_get_vocab(model);
        e->n_threads = std::max(1, (int) nThreads);

        // Find the largest context size that actually allocates; degrade gracefully on low RAM.
        int candidates[] = {(int) nCtx, 2048, 1024, 512};
        int last = 1 << 30;
        e->n_ctx = 0;
        for (int c : candidates) {
            if (c <= 0 || c >= last) continue;
            last = c;
            llama_context *test = make_ctx(e, c);
            if (test) { llama_free(test); e->n_ctx = c; break; }
            LOGE("context %d allocate nahi hua, chhota try kar raha hoon", c);
        }
        if (e->n_ctx == 0) {
            std::string why = take_last_err();
            llama_model_free(e->model);
            delete e;
            throw_rt(env, "RAM kam hai: inference context bana nahi paya. Chhota model/quantization try karo. " + why);
            return 0;
        }
        LOGI("model loaded, n_ctx=%d threads=%d", e->n_ctx, e->n_threads);
        return reinterpret_cast<jlong>(e);
    } catch (const std::exception &ex) {
        if (e) { if (e->model) llama_model_free(e->model); delete e; }
        throw_rt(env, std::string("Native error: ") + ex.what());
        return 0;
    }
}

JNIEXPORT jint JNICALL
Java_com_memoir_ai_ai_NativeLlama_nContextSize(JNIEnv *, jobject, jlong h) {
    Engine *e = reinterpret_cast<Engine *>(h);
    return e ? e->n_ctx : 0;
}

JNIEXPORT void JNICALL
Java_com_memoir_ai_ai_NativeLlama_nCancel(JNIEnv *, jobject, jlong h) {
    Engine *e = reinterpret_cast<Engine *>(h);
    if (e) e->cancel = true;
}

JNIEXPORT void JNICALL
Java_com_memoir_ai_ai_NativeLlama_nFree(JNIEnv *, jobject, jlong h) {
    Engine *e = reinterpret_cast<Engine *>(h);
    if (!e) return;
    e->cancel = true;
    {
        std::lock_guard<std::mutex> lk(e->gen_mu);   // wait for any running generation to stop
        if (e->model) llama_model_free(e->model);
        e->model = nullptr;
    }
    delete e;
}

JNIEXPORT jstring JNICALL
Java_com_memoir_ai_ai_NativeLlama_nSystemInfo(JNIEnv *env, jobject) {
    return env->NewStringUTF(llama_print_system_info());
}

// Returns number of generated tokens. Streams UTF-8 byte chunks to cb.onToken(byte[]): Boolean (false = stop).
JNIEXPORT jint JNICALL
Java_com_memoir_ai_ai_NativeLlama_nGenerate(JNIEnv *env, jobject, jlong h, jbyteArray jprompt,
                                           jint maxNew, jfloat temp, jobject cb) {
    Engine *e = reinterpret_cast<Engine *>(h);
    if (!e || !e->model) { throw_rt(env, "Model load nahi hai"); return -1; }
    std::unique_lock<std::mutex> lk(e->gen_mu, std::try_to_lock);
    if (!lk.owns_lock()) { throw_rt(env, "Model abhi dusra jawab bana raha hai"); return -1; }
    e->cancel = false;

    CtxGuard g;
    try {
        std::string prompt = to_str(env, jprompt);
        jclass cls = env->GetObjectClass(cb);
        jmethodID mid = env->GetMethodID(cls, "onToken", "([B)Z");
        if (!mid) { throw_rt(env, "Callback method nahi mila"); return -1; }

        // --- tokenize (parse_special=true so <|im_start|> etc. become real control tokens) ---
        int n = -llama_tokenize(e->vocab, prompt.c_str(), (int32_t) prompt.size(), nullptr, 0, true, true);
        if (n <= 0) { throw_rt(env, "Prompt tokenize nahi hua"); return -1; }
        std::vector<llama_token> toks((size_t) n);
        if (llama_tokenize(e->vocab, prompt.c_str(), (int32_t) prompt.size(), toks.data(), n, true, true) < 0) {
            throw_rt(env, "Prompt tokenize nahi hua");
            return -1;
        }

        int max_new = std::max(16, std::min((int) maxNew, e->n_ctx / 2));
        int limit = e->n_ctx - max_new - 4;
        if ((int) toks.size() > limit) {
            // Last-resort safety net (Kotlin already trims the prompt): keep first token + newest tokens.
            LOGE("prompt %d tokens > limit %d, truncating", (int) toks.size(), limit);
            std::vector<llama_token> t2;
            t2.push_back(toks[0]);
            t2.insert(t2.end(), toks.end() - (limit - 1), toks.end());
            toks.swap(t2);
        }

        g.ctx = make_ctx(e, e->n_ctx);
        if (!g.ctx) { throw_rt(env, "Context bana nahi paya (RAM kam). Model unload karke dobara load karo."); return -1; }

        // --- sampler: top-k -> top-p -> temperature -> random (or greedy when temp <= 0) ---
        g.smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
        if (temp <= 0.f) {
            llama_sampler_chain_add(g.smpl, llama_sampler_init_greedy());
        } else {
            llama_sampler_chain_add(g.smpl, llama_sampler_init_top_k(40));
            llama_sampler_chain_add(g.smpl, llama_sampler_init_top_p(0.9f, 1));
            llama_sampler_chain_add(g.smpl, llama_sampler_init_temp(temp));
            llama_sampler_chain_add(g.smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
        }

        // --- prefill in n_batch chunks ---
        const int n_batch = 512;
        for (size_t i = 0; i < toks.size(); i += n_batch) {
            if (e->cancel) return 0;
            int cnt = (int) std::min((size_t) n_batch, toks.size() - i);
            llama_batch b = llama_batch_get_one(toks.data() + i, cnt);
            if (llama_decode(g.ctx, b) != 0) { throw_rt(env, "Prompt decode fail (context bhar gaya ya RAM kam)"); return -1; }
        }

        // --- generate ---
        std::string pending;
        int generated = 0;
        for (; generated < max_new; ++generated) {
            if (e->cancel) break;
            llama_token tok = llama_sampler_sample(g.smpl, g.ctx, -1);
            if (llama_vocab_is_eog(e->vocab, tok)) break;

            char buf[256];
            int len = llama_token_to_piece(e->vocab, tok, buf, sizeof(buf), 0, false);
            if (len > 0) {
                pending.append(buf, (size_t) len);
                size_t ok = complete_utf8_len(pending);
                if (ok > 0) {
                    bool cont = emit(env, cb, mid, pending.data(), ok);
                    pending.erase(0, ok);
                    if (!cont) { ++generated; break; }
                }
            }
            llama_batch nb = llama_batch_get_one(&tok, 1);
            if (llama_decode(g.ctx, nb) != 0) { LOGE("decode failed during generation"); break; }
        }
        if (!pending.empty() && !e->cancel) emit(env, cb, mid, pending.data(), pending.size());
        return generated;
    } catch (const std::exception &ex) {
        throw_rt(env, std::string("Native error: ") + ex.what());
        return -1;
    }
}

}  // extern "C"
