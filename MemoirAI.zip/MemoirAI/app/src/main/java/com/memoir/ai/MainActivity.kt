package com.memoir.ai

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.memoir.ai.data.Crypto
import com.memoir.ai.data.Repo
import com.memoir.ai.ui.MemoirTheme
import com.memoir.ai.ui.Root

class MemoirApp : Application() {
    lateinit var repo: Repo
    override fun onCreate() { super.onCreate(); Crypto.init(this); repo = Repo(this) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MemoirTheme { Root() } }
    }
}
