package com.memoir.ai.ai

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.memoir.ai.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Inference backend abstraction. Implementations live in src/llama (real) and src/noLlama (stub). */
interface LlmEngine {
    val isLoaded: Boolean
    /** Context window in tokens of the loaded model (used to size prompts). */
    val contextSize: Int
    suspend fun load(path: String): Result<Unit>
    fun generate(prompt: String, onProgress: (Int, Int) -> Unit = { _, _ -> }): Flow<String>
    suspend fun unload()
}

object Prompt {
    fun build(tpl: String, system: String, turns: List<Pair<String, String>>): String = when (tpl) {
        "llama3" -> "<|start_header_id|>system<|end_header_id|>\n\n$system<|eot_id|>" +
            turns.joinToString("") { "<|start_header_id|>${it.first}<|end_header_id|>\n\n${it.second}<|eot_id|>" } +
            "<|start_header_id|>assistant<|end_header_id|>\n\n"
        "gemma" -> { // Gemma has no system role: fold it into the first user turn
            val t = turns.toMutableList(); if (t.isNotEmpty()) t[0] = t[0].first to (system + "\n\n" + t[0].second)
            t.joinToString("") { "<start_of_turn>${if (it.first == "assistant") "model" else "user"}\n${it.second}<end_of_turn>\n" } + "<start_of_turn>model\n"
        }
        else -> "<|im_start|>system\n$system<|im_end|>\n" +
            turns.joinToString("") { "<|im_start|>${it.first}\n${it.second}<|im_end|>\n" } + "<|im_start|>assistant\n"
    }
}

class ChatEngine(private val repo: Repo, private val engine: LlmEngine, private val template: () -> String) {
    data class Turn(val saved: List<String>, val pending: List<Candidate>, val error: String? = null, val stats: String? = null)

    private val SYSTEM = "Tu Memoir AI hai, user ka private assistant. Natural Hinglish (Roman script) mein chhota, warm jawab de. " +
        "User ke baare mein sirf neeche 'YAAD' mein likhi baatein use kar; jo wahan nahi hai use invent mat kar, bol de 'yaad nahi hai'."

    private val fmt get() = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
    private fun clean(s: String) = s.replace(Regex("<\\|[^>]*\\|>|<end_of_turn>|<start_of_turn>(model|user)?"), "").trim()

    suspend fun respond(user: String, autoSave: Boolean, onUser: suspend () -> Unit, onStatus: (String) -> Unit = {}, onToken: (String) -> Unit): Turn {
        val dao = repo.dao
        val now = System.currentTimeMillis()
        val history = dao.lastMessages(4).reversed()
        dao.saveMessage(Message(role = "user", text = Secret(user), ts = now)); onUser()

        // 1) retrieve BEFORE saving so the new statement doesn't retrieve itself
        val isQ = Extractor.isQuestion(user)
        val memQ = Extractor.isMemoryQuery(user)
        val hits = if (isQ || engine.isLoaded) repo.search(user, 4, if (isQ) TimeParse.range(user) else null, if (isQ) Extractor.categoryHint(user) else null) else emptyList()
        val goals = if (Extractor.mentionsGoals(user)) dao.goals().filter { !it.done } else emptyList()

        // 2) extract + save (sensitive => pending, user must approve)
        val saved = mutableListOf<String>(); val pend = mutableListOf<Candidate>()
        if (autoSave) for (c in Extractor.extract(user)) {
            if (c.sensitive) { pend += c; continue }
            repo.logJournal(c.text, now)
            if (c.importance >= 3) {
                if (repo.saveCandidate(c) != Outcome.DUPLICATE) saved += c.text
                if (c.category == "Goals") repo.addGoalIfNew(c.text)
            }
        }

        // 3) reply
        var reply: String? = null
        var llmError: String? = null
        var stats: String? = null
        if (memQ && hits.isEmpty() && goals.isEmpty()) {
            reply = "Is baare mein mere paas abhi kuch save nahi hai. Aap bataoge to main yaad rakh lunga 🙂"
        } else if (engine.isLoaded) {
            val sb = StringBuilder()
            try {
                val prompt = fitPrompt(user, history, hits, goals, saved, pend, now)
                val t0 = System.nanoTime(); var first = -1L; var chunks = 0
                engine.generate(prompt) { d, t -> onStatus("⏳ Prompt padh raha hoon… $d/$t tokens") }.collect { tok ->
                    if (first < 0) first = System.nanoTime() - t0
                    chunks++
                    sb.append(tok); if (!tok.contains("<|") && !tok.contains("<end_of_turn>")) onToken(tok)
                }
                val secs = (System.nanoTime() - t0) / 1e9
                if (chunks > 0) stats = String.format(Locale.US, "pehla token %.1fs · %.1f tok/s", first / 1e9, chunks / secs)
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { llmError = e.message ?: "LLM error" }
            reply = clean(sb.toString()).ifBlank { null }
        }
        var finalReply: String = reply ?: fallback(hits, goals, saved, pend, isQ)
        if (engine.isLoaded && reply == null) finalReply += if (llmError != null) "\n\n⚠ AI engine error: $llmError"
            else "\n\n⚠ Model ne khaali jawab diya (prompt template galat ho sakta hai: ${template()}). Settings → Test AI chalao."
        dao.saveMessage(Message(role = "assistant", text = Secret(finalReply), ts = System.currentTimeMillis()))
        return Turn(saved, pend, llmError, stats)
    }

    /** Builds the chat prompt and shrinks it (oldest history first, then memories) until it fits the model's context. */
    private fun fitPrompt(user: String, history: List<Message>, hits: List<Hit>, goals: List<Goal>,
                          saved: List<String>, pend: List<Candidate>, now: Long): String {
        val ctx = engine.contextSize
        val maxNew = minOf(256, ctx / 4)
        val budget = ((ctx - maxNew - 48) * 3).coerceIn(1200, 3200)   // lean prompt = fast first token on weak CPUs   // ~3 chars/token for Hinglish
        val ranked = hits.sortedByDescending { it.score }
        var hN = history.size
        var mN = ranked.size
        fun make(): String {
            val mem = StringBuilder()
            ranked.take(mN).sortedBy { it.m.createdAt }.forEach {
                val line = "- [${fmt.format(Date(it.m.createdAt))} | ${it.m.category}] ${it.m.text.v.take(220)}\n"
                if (mem.length + line.length < 900) mem.append(line)
            }
            val sys = buildString {
                append(SYSTEM).append("\nAaj ki date: ").append(fmt.format(Date(now)))
                append("\nYAAD:\n").append(if (mem.isEmpty()) "(kuch relevant save nahi hai)" else mem)
                if (goals.isNotEmpty()) append("OPEN GOALS/TASKS:\n").append(goals.joinToString("\n") { "- ${it.title.v} (${it.progress}%)" }).append("\n")
                if (saved.isNotEmpty()) append("Abhi save hua: ").append(saved.joinToString(" | ")).append("\n")
                if (pend.isNotEmpty()) append("Note: kuch sensitive info save karne se pehle user se permission maangi ja rahi hai; use bol de ki neeche confirm kare.\n")
            }
            val turns = history.takeLast(hN).map { (if (it.role == "user") "user" else "assistant") to it.text.v.take(250) }
                .dropWhile { it.first == "assistant" } + ("user" to user.take(2000))
            return Prompt.build(template(), sys, turns)
        }
        var p = make()
        while (p.length > budget && (hN > 0 || mN > 0)) { if (hN > 0) hN-- else mN--; p = make() }
        return p
    }

    /** Offline-memory mode: deterministic, grounded replies built only from saved data. */
    private fun fallback(hits: List<Hit>, goals: List<Goal>, saved: List<String>, pend: List<Candidate>, isQ: Boolean): String = buildString {
        if (hits.isNotEmpty() && isQ) {
            append("Mere saved notes ke hisaab se:\n")
            hits.forEach { append("• ${fmt.format(Date(it.m.createdAt))} (${it.m.category}): ${it.m.text.v}\n") }
        }
        if (goals.isNotEmpty()) append("\nOpen goals/tasks:\n").append(goals.joinToString("\n") { "• ${it.title.v} — ${it.progress}%" }).append("\n")
        if (saved.isNotEmpty()) append("Samajh gaya 👍 Ye maine yaad rakh liya:\n").append(saved.joinToString("\n") { "• $it" }).append("\n")
        if (pend.isNotEmpty()) append("\nKuch sensitive lag raha hai — save karne se pehle aapki permission chahiye (neeche).\n")
        if (isEmpty()) append(if (engine.isLoaded) "Theek hai, sun raha hoon. Aur batao?" else "Theek hai, sun raha hoon. Aur batao? (AI model load nahi hai — Settings mein model Load karoge to main natural baat kar paunga.)")
    }.trim()
}

// ------------------------------ models ------------------------------
data class Preset(val name: String, val file: String, val url: String, val template: String, val sizeMb: Int)

object ModelStore {
    // Links point to public Hugging Face GGUF files. Verify availability; you can always import any .gguf manually.
    val presets = listOf(
        Preset("Qwen2.5 0.5B Instruct (Q4) — FAST, weak phones (Redmi Note 8)", "qwen2.5-0.5b-instruct-q4_k_m.gguf", "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf", "chatml", 400),
        Preset("Qwen2.5 1.5B Instruct (Q4) — light", "qwen2.5-1.5b-instruct-q4_k_m.gguf", "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf", "chatml", 1100),
        Preset("Qwen2.5 3B Instruct (Q4) — better Hinglish", "qwen2.5-3b-instruct-q4_k_m.gguf", "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf", "chatml", 2000),
        Preset("Llama 3.2 1B Instruct (Q4) — lightest", "Llama-3.2-1B-Instruct-Q4_K_M.gguf", "https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf", "llama3", 800),
        Preset("Llama 3.2 3B Instruct (Q4)", "Llama-3.2-3B-Instruct-Q4_K_M.gguf", "https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf", "llama3", 2000),
        Preset("Gemma 2 2B it (Q4)", "gemma-2-2b-it-Q4_K_M.gguf", "https://huggingface.co/bartowski/gemma-2-2b-it-GGUF/resolve/main/gemma-2-2b-it-Q4_K_M.gguf", "gemma", 1700)
    )
    data class Ram(val ok: Boolean, val msg: String?)
    private fun memInfo(ctx: Context) = ActivityManager.MemoryInfo().also { (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it) }

    /** Pre-flight RAM check so a too-large model is refused instead of getting the app killed by Android. */
    fun ramCheck(ctx: Context, f: File): Ram {
        val mi = memInfo(ctx); val size = f.length(); val mb = 1_000_000L
        return when {
            !f.exists() -> Ram(false, "Model file nahi mili")
            size > mi.totalMem * 8 / 10 -> Ram(false, "Ye model (${size / mb} MB) is phone ki RAM (${mi.totalMem / mb} MB) ke liye bahut bada hai. 1B/1.5B Q4 model try karo.")
            size > mi.availMem * 8 / 10 -> Ram(true, "Free RAM kam hai (${mi.availMem / mb} MB). Dusre apps band karo; load slow ya fail ho sakta hai.")
            else -> Ram(true, null)
        }
    }
    fun ramLine(ctx: Context): String { val mi = memInfo(ctx); return "RAM: ${mi.availMem / 1_000_000} MB free / ${mi.totalMem / 1_000_000} MB" }

    fun dir(ctx: Context) = File(ctx.filesDir, "models").apply { mkdirs() }
    fun list(ctx: Context): List<File> = dir(ctx).listFiles { f -> f.extension == "gguf" }?.toList() ?: emptyList()

    /** Resumable download (HTTP Range) into app-private storage. */
    suspend fun download(ctx: Context, p: Preset, onProgress: (Float) -> Unit): File = withContext(Dispatchers.IO) {
        val dest = File(dir(ctx), p.file); if (dest.exists()) return@withContext dest
        val part = File(dir(ctx), p.file + ".part"); val have = part.length()
        val c = URL(p.url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
        c.connect()
        val code = c.responseCode
        if (code != 200 && code != 206) error("HTTP $code")
        val append = code == 206
        var done = if (append) have else 0L
        val total = c.contentLengthLong + if (append) have else 0L
        FileOutputStream(part, append).use { out -> c.inputStream.use { inp ->
            val buf = ByteArray(64 * 1024)
            while (true) { val n = inp.read(buf); if (n < 0) break; out.write(buf, 0, n); done += n; if (total > 0) onProgress(done.toFloat() / total); ensureActive() }
        } }
        part.renameTo(dest); dest
    }

    fun copyFrom(ctx: Context, uri: Uri): File {
        val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) c.getString(i) else null } ?: "imported.gguf"
        val dest = File(dir(ctx), if (name.endsWith(".gguf")) name else "$name.gguf")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        return dest
    }
}
