package com.memoir.ai.ai

import android.util.Base64
import java.nio.ByteBuffer
import kotlin.math.sqrt

/**
 * Fully local, zero-download semantic vectors (feature hashing over words, char-trigrams, bigrams).
 * Works for Hinglish/Hindi-in-Roman because it is lexical-subword based, not language-specific.
 * It is NOT a neural embedding; swap `embed()` for a GGUF embedding model later without touching callers.
 */
object Embedder {
    const val D = 256
    val STOP: Set<String> = ("hai hain ka ki ke ko se me mein main mai mera meri mere mujhe maine tha thi the aur ya to toh ye yeh wo woh " +
        "kya kab kaise kuch bhi hi na nahi hu hoon ho kar karna raha rahi rha rhi liye lie par pe ab jo jab tab is us in un " +
        "a an the is are was were am i my me we our you your of to and in on for it that this with at by be been do did does have has had " +
        "from as or but not what when how which who tell told discuss last month week today yesterday pichle pichhle mahine hafte bataya batao bata please about").split(" ").toSet()

    fun tokens(t: String): List<String> = t.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 1 && it !in STOP }

    fun embed(text: String): FloatArray {
        val v = FloatArray(D)
        val tk = tokens(text)
        fun add(s: String, w: Float) {
            val h = s.hashCode() * -1640531535
            val i = (h ushr 1) % D
            v[i] += if ((h and 1) == 0) w else -w
        }
        tk.forEach { add("w$it", 1f); val p = "#$it#"; for (i in 0..p.length - 3) add("c" + p.substring(i, i + 3), 0.25f) }
        for (i in 0 until tk.size - 1) add("b${tk[i]} ${tk[i + 1]}", 0.5f)
        val n = sqrt(v.sumOf { (it * it).toDouble() }).toFloat()
        if (n > 0) for (i in v.indices) v[i] /= n
        return v
    }

    fun cos(a: FloatArray, b: FloatArray): Float { var s = 0f; for (i in a.indices) s += a[i] * b[i]; return s }

    fun encode(v: FloatArray): String {
        val bb = ByteBuffer.allocate(D * 4); bb.asFloatBuffer().put(v)
        return Base64.encodeToString(bb.array(), Base64.NO_WRAP)
    }
    fun decode(s: String): FloatArray {
        val out = FloatArray(D)
        try { ByteBuffer.wrap(Base64.decode(s, Base64.NO_WRAP)).asFloatBuffer().get(out) } catch (_: Exception) {}
        return out
    }
}
