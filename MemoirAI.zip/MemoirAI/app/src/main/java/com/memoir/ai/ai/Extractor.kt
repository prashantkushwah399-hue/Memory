package com.memoir.ai.ai

import java.util.Calendar

data class Candidate(val text: String, val category: String, val importance: Int, val sensitive: Boolean)

val CATEGORIES = listOf("Personal Life", "Daily Activities", "Goals", "Projects", "Ideas", "Experiences", "Preferences", "Important Events")

/**
 * Decides WHAT is worth remembering. Rule-based on purpose: deterministic, instant, works with no model,
 * and never invents text — a memory is always the user's own sentence.
 * Policy:
 *  - questions, chit-chat and sentences without a first-person/strong signal are ignored
 *  - "Daily Activities" go to the Journal only (importance 2) unless the user says "yaad rakhna"
 *  - sensitive content is never stored silently; it is returned flagged so the UI can ask permission
 */
object Extractor {
    private val FIRST = Regex("\\b(main|mai|mera|meri|mere|mujhe|mujhko|maine|humne|hum|hamara|i|my|i'm|ive|i've)\\b")
    private val Q_START = Regex("^(kya|kab|kaun|kaise|kyun|kyu|kitna|kitne|kahan|what|when|who|how|why|where|which|tell|show|list|batao|bata)\\b")
    private val REMEMBER = Regex("\\b(yaad rakh|yaad rakhna|remember|note kar|note this|save kar)\\b")
    private val IMPORTANT = Regex("\\b(important|zaroori|zaruri|bahut khaas|must)\\b")
    private val SENS = Regex("\\b(password|pin|otp|cvv|aadhaar|aadhar|pan card|pan number|bank|account number|card number|ssn|passport|medical|diagnos\\w*|depress\\w*|anxiety|salary|loan|debt|religion|sexual|illness|disease|medicine|dawai)\\b|\\d{9,}")

    private val rules = listOf(
        "Goals" to Regex("\\b(goal|target|sapna|dream|want to|wanna|chahta|chahti|banna chahta|banna chahti|seekhna|resolution|aim|plan hai|plan kar)\\b"),
        "Projects" to Regex("\\b(project|startup|website|thesis|assignment|building|bana raha|bana rahi|develop\\w*|launch\\w*|prototype|client)\\b"),
        "Ideas" to Regex("\\b(idea|soch raha|soch rahi|what if|concept|socha)\\b"),
        "Important Events" to Regex("\\b(birthday|anniversary|exam|interview|wedding|shaadi|meeting|deadline|appointment|result|promotion|selected|admission|trip|flight)\\b"),
        "Preferences" to Regex("\\b(pasand|favourite|favorite|i like|i love|love|hate|prefer|allergic|fav)\\b"),
        "Personal Life" to Regex("\\b(mera naam|my name|family|maa|papa|bhai|behen|sister|brother|wife|husband|girlfriend|friend|dost|rehta|rehti|live in|job|work at|kaam karta|kaam karti|college|school)\\b"),
        "Experiences" to Regex("\\b(experience|feel kiya|accha laga|bura laga|sikha|learned|realised|realized|mehsoos)\\b"),
        "Daily Activities" to Regex("\\b(aaj|today|gaya|gayi|kiya|kar liya|khaya|padha|workout|gym|walk|office|bought|kharida)\\b")
    )
    private val base = mapOf("Goals" to 4, "Projects" to 4, "Important Events" to 4, "Personal Life" to 4,
        "Preferences" to 3, "Ideas" to 3, "Experiences" to 3, "Daily Activities" to 2)

    fun isQuestion(t: String): Boolean { val l = t.lowercase().trim(); return l.contains("?") || Q_START.containsMatchIn(l) }
    fun isMemoryQuery(t: String) = isQuestion(t) && Regex("\\b(yaad|remember|recall|did i|what did i|discuss\\w*|journal|bataya|bataaya)\\b|\\bmaine\\b.*\\b(kaha|bola|bataya|share|discuss\\w*)\\b|\\b(mere|meri|my)\\s+(goals?|projects?|ideas?|plans?|tasks?|notes?|memories|journal|preferences?)\\b").containsMatchIn(t.lowercase())
    fun mentionsGoals(t: String) = Regex("\\b(goals?|tasks?|plans?|pending|target|lakshya)\\b").containsMatchIn(t.lowercase())
    fun categoryHint(t: String): String? { val l = t.lowercase(); return when {
        Regex("\\b(goals?|targets?|lakshya)\\b").containsMatchIn(l) -> "Goals"
        Regex("\\bprojects?\\b").containsMatchIn(l) -> "Projects"
        Regex("\\bideas?\\b").containsMatchIn(l) -> "Ideas"
        Regex("\\b(pasand|preferences?|favou?rite)\\b").containsMatchIn(l) -> "Preferences"
        Regex("\\b(deadlines?|birthday|events?)\\b").containsMatchIn(l) -> "Important Events"
        else -> null } }

    fun sentences(t: String) = t.split(Regex("(?<=[.!?।\\n])\\s+")).map { it.trim() }.filter { it.length >= 10 }

    fun extract(text: String): List<Candidate> {
        val force = REMEMBER.containsMatchIn(text.lowercase())
        return sentences(text).mapNotNull { s ->
            val l = s.lowercase()
            if (l.endsWith("?") || Q_START.containsMatchIn(l)) return@mapNotNull null
            val cat = rules.firstOrNull { it.second.containsMatchIn(l) }?.first
            if (!force && (cat == null || !FIRST.containsMatchIn(l) || Embedder.tokens(l).size < 3)) return@mapNotNull null
            val imp = if (force || IMPORTANT.containsMatchIn(l)) 5 else base[cat] ?: 3
            Candidate(s, cat ?: "Personal Life", imp, SENS.containsMatchIn(l))
        }
    }
}

/** Natural-language time ranges in English + Hinglish. Returns null if none found. */
object TimeParse {
    private fun d0(now: Long, off: Int = 0) = Calendar.getInstance().apply {
        timeInMillis = now; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, off) }
    fun range(q: String, now: Long = System.currentTimeMillis()): LongRange? {
        val l = q.lowercase()
        fun has(p: String) = Regex(p).containsMatchIn(l)
        val monday = d0(now).apply { add(Calendar.DAY_OF_YEAR, -((get(Calendar.DAY_OF_WEEK) + 5) % 7)) }
        val som = d0(now).apply { set(Calendar.DAY_OF_MONTH, 1) }
        return when {
            has("last month|pichle mahine|pichhle mahine|pichle month|previous month") ->
                d0(now).apply { set(Calendar.DAY_OF_MONTH, 1); add(Calendar.MONTH, -1) }.timeInMillis until som.timeInMillis
            has("this month|is mahine|is month") -> som.timeInMillis..now
            has("last week|pichle hafte|pichhle hafte|pichle week|pichhle week") ->
                d0(monday.timeInMillis, -7).timeInMillis until monday.timeInMillis
            has("this week|is hafte|is week") -> monday.timeInMillis..now
            has("yesterday|beeta kal") -> d0(now, -1).timeInMillis until d0(now).timeInMillis
            has("today|\\baaj\\b") -> d0(now).timeInMillis..now
            else -> Regex("(\\d+)\\s*(days|din)").find(l)?.let { (now - it.groupValues[1].toLong() * 86_400_000L)..now }
        }
    }
}
