package com.memoir.ai.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Field-level encryption at rest.
 * A random 256-bit data key is wrapped by a hardware-backed Android Keystore key.
 * All sensitive DB columns (memory text, embeddings, messages, journal, goals) are AES-256-GCM.
 */
object Crypto {
    private const val T = "AES/GCM/NoPadding"
    private lateinit var dataKey: SecretKey
    private val rnd = SecureRandom()

    fun init(ctx: Context) {
        val sp = ctx.getSharedPreferences("memoir_keys", Context.MODE_PRIVATE)
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias("memoir_master")) {
            KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
                init(KeyGenParameterSpec.Builder("memoir_master", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build())
            }.generateKey()
        }
        val master = ks.getKey("memoir_master", null) as SecretKey
        val stored = sp.getString("dk", null)
        val raw = if (stored == null) {
            val k = ByteArray(32).also(rnd::nextBytes)
            val c = Cipher.getInstance(T).apply { init(Cipher.ENCRYPT_MODE, master) }
            sp.edit().putString("dk", Base64.encodeToString(c.iv + c.doFinal(k), Base64.NO_WRAP)).apply()
            k
        } else {
            val b = Base64.decode(stored, Base64.NO_WRAP)
            val c = Cipher.getInstance(T).apply { init(Cipher.DECRYPT_MODE, master, GCMParameterSpec(128, b, 0, 12)) }
            c.doFinal(b, 12, b.size - 12)
        }
        dataKey = SecretKeySpec(raw, "AES")
    }

    private fun seal(k: SecretKey, p: ByteArray): ByteArray {
        val iv = ByteArray(12).also(rnd::nextBytes)
        val c = Cipher.getInstance(T).apply { init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, iv)) }
        return iv + c.doFinal(p)
    }
    private fun open(k: SecretKey, b: ByteArray): ByteArray {
        val c = Cipher.getInstance(T).apply { init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, b, 0, 12)) }
        return c.doFinal(b, 12, b.size - 12)
    }

    fun enc(s: String): String = Base64.encodeToString(seal(dataKey, s.toByteArray()), Base64.NO_WRAP)
    fun dec(s: String): String = try { String(open(dataKey, Base64.decode(s, Base64.NO_WRAP))) } catch (e: Exception) { "[unreadable]" }

    private fun derive(pass: CharArray, salt: ByteArray): SecretKey =
        SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pass, salt, 120_000, 256)).encoded, "AES")

    /** Passphrase-protected backup blob: salt(16) | iv(12) | ciphertext. */
    fun sealWithPass(p: ByteArray, pass: CharArray): ByteArray {
        val salt = ByteArray(16).also(rnd::nextBytes)
        return salt + seal(derive(pass, salt), p)
    }
    fun openWithPass(b: ByteArray, pass: CharArray): ByteArray =
        open(derive(pass, b.copyOfRange(0, 16)), b.copyOfRange(16, b.size))
}
