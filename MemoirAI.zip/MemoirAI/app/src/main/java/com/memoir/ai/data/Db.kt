package com.memoir.ai.data

import androidx.room.*

/** Wrapper type so Room transparently encrypts/decrypts the column. */
data class Secret(val v: String)
class Conv {
    @TypeConverter fun enc(s: Secret): String = Crypto.enc(s.v)
    @TypeConverter fun dec(s: String): Secret = Secret(Crypto.dec(s))
}

@Entity(tableName = "memories")
data class Memory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: Secret,
    val category: String,
    val createdAt: Long,
    val updatedAt: Long,
    val importance: Int = 3,
    val embedding: Secret,          // base64 float vector, encrypted
    val threadId: Long = 0,         // memories about the same topic share a thread
    val status: String = "active"   // active | outdated
)

@Entity(tableName = "messages")
data class Message(@PrimaryKey(autoGenerate = true) val id: Long = 0, val role: String, val text: Secret, val ts: Long)

@Entity(tableName = "journal")
data class Journal(@PrimaryKey(autoGenerate = true) val id: Long = 0, val day: String, val text: Secret, val auto: Boolean, val updatedAt: Long)

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: Secret, val done: Boolean = false, val progress: Int = 0,
    val isTask: Boolean = false, val createdAt: Long, val updatedAt: Long
)

@Dao
interface AppDao {
    @Query("SELECT * FROM memories ORDER BY updatedAt DESC") suspend fun memories(): List<Memory>
    @Query("SELECT * FROM memories WHERE id=:id") suspend fun memory(id: Long): Memory?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveMemory(m: Memory): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveMemories(m: List<Memory>)
    @Query("DELETE FROM memories WHERE id=:id") suspend fun deleteMemory(id: Long)
    @Query("DELETE FROM memories") suspend fun clearMemories()

    @Query("SELECT * FROM messages ORDER BY id") suspend fun messages(): List<Message>
    @Query("SELECT * FROM messages ORDER BY id DESC LIMIT :n") suspend fun lastMessages(n: Int): List<Message>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveMessage(m: Message): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveMessages(m: List<Message>)
    @Query("DELETE FROM messages") suspend fun clearMessages()

    @Query("SELECT * FROM journal ORDER BY day DESC, id DESC") suspend fun journal(): List<Journal>
    @Query("SELECT * FROM journal WHERE day=:d AND auto=1 LIMIT 1") suspend fun autoJournal(d: String): Journal?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveJournal(j: Journal): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveJournals(j: List<Journal>)
    @Query("DELETE FROM journal WHERE id=:id") suspend fun deleteJournal(id: Long)
    @Query("DELETE FROM journal") suspend fun clearJournal()

    @Query("SELECT * FROM goals ORDER BY done, updatedAt DESC") suspend fun goals(): List<Goal>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveGoal(g: Goal): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveGoals(g: List<Goal>)
    @Query("DELETE FROM goals WHERE id=:id") suspend fun deleteGoal(id: Long)
    @Query("DELETE FROM goals") suspend fun clearGoals()
}

/**
 * version=1. When the schema changes, bump the version and add a Migration in Repo's builder.
 * There is deliberately NO fallbackToDestructiveMigration(): updates must never wipe user data.
 */
@Database(entities = [Memory::class, Message::class, Journal::class, Goal::class], version = 1, exportSchema = true)
@TypeConverters(Conv::class)
abstract class Db : RoomDatabase() { abstract fun dao(): AppDao }
