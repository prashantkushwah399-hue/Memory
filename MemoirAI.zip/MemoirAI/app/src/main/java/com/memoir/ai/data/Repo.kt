package com.memoir.ai.data

import android.content.Context
import androidx.room.Room
import com.memoir.ai.ai.Candidate
import com.memoir.ai.ai.Embedder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.exp
import kotlin.math.max

enum class Outcome { NEW, LINKED, SUPERSEDED, DUPLICATE }
data class Hit(val m: Memory, val score: Float)
data class Section(val title: String, val lines: List<String>)

/** The heart of the app: storage, dedupe, linking, semantic retrieval, insights, backup. */
class Repo(ctx: Context) {
    val dao: AppDao = Room.databaseBuilder(ctx, Db::class.java, "memoir.db")
        // .addMigrations(MIGRATION_1_2)  <- add here in future versions. Never use destructive fallback.
        .build().dao()

    private class Mem(val m: Memory, val v: FloatArray)
    private val lock = Mutex()
    private var cache: List<Mem>? = null
    private fun invalidate() { cache = null }
    private suspend fun mems(): List<Mem> = cache ?: lock.withLock {
        cache ?: withContext(Dispatchers.Default) {
            dao.memories().map { Mem(it, Embedder.decode(it.embedding.v)) }
        }.also { cache = it }
    }

    companion object {
        const val DUP = 0.85f        // same category + this similar => duplicate
        const val LINK = 0.35f       // >= this => same topic thread (project history etc.)
        const val SUPERSEDE = 0.50f  // Preferences/Personal Life this similar => older one marked outdated
        const val DAY = 86_400_000L
    }

    suspend fun allMemories(): List<Memory> = mems().map { it.m }

    // ---------- save / dedupe / link ----------
    suspend fun saveCandidate(c: Candidate): Outcome {
        val now = System.currentTimeMillis()
        val v = Embedder.embed(c.text)
        val active = mems().filter { it.m.status == "active" }
        val best = active.maxByOrNull { Embedder.cos(v, it.v) }
        val sim = best?.let { Embedder.cos(v, it.v) } ?: 0f
        if (best != null && sim >= DUP && best.m.category == c.category) {
            dao.saveMemory(best.m.copy(updatedAt = now, importance = max(best.m.importance, c.importance)))
            invalidate(); return Outcome.DUPLICATE
        }
        var thread = 0L
        var outcome = Outcome.NEW
        if (best != null && sim >= LINK) {
            thread = best.m.threadId; outcome = Outcome.LINKED
            if (sim >= SUPERSEDE && best.m.category == c.category && c.category in setOf("Preferences", "Personal Life")) {
                dao.saveMemory(best.m.copy(status = "outdated")); outcome = Outcome.SUPERSEDED
            }
        }
        val id = dao.saveMemory(Memory(text = Secret(c.text), category = c.category, createdAt = now, updatedAt = now,
            importance = c.importance, embedding = Secret(Embedder.encode(v)), threadId = thread))
        if (thread == 0L) dao.memory(id)?.let { dao.saveMemory(it.copy(threadId = id)) }
        invalidate(); return outcome
    }

    suspend fun editMemory(m: Memory, text: String, cat: String) {
        dao.saveMemory(m.copy(text = Secret(text), category = cat, updatedAt = System.currentTimeMillis(),
            embedding = Secret(Embedder.encode(Embedder.embed(text)))))
        invalidate()
    }
    suspend fun setStatus(m: Memory, status: String) { dao.saveMemory(m.copy(status = status)); invalidate() }
    suspend fun deleteMemory(id: Long) { dao.deleteMemory(id); invalidate() }
    suspend fun thread(id: Long): List<Memory> = mems().map { it.m }.filter { it.threadId == id }.sortedBy { it.createdAt }

    // ---------- retrieval ----------
    /** Hybrid score: 0.6 semantic cosine + 0.3 keyword overlap + small recency/importance prior. */
    suspend fun search(q: String, k: Int = 6, range: LongRange? = null, cat: String? = null, withThread: Boolean = true): List<Hit> {
        val qv = Embedder.embed(q)
        val qt = Embedder.tokens(q).toSet()
        val now = System.currentTimeMillis()
        val th = if (range != null || cat != null) -1f else 0.14f
        val scored = mems().filter {
            it.m.status == "active" && (cat == null || it.m.category == cat) &&
                (range == null || it.m.createdAt in range || it.m.updatedAt in range)
        }.map { e ->
            val mt = Embedder.tokens(e.m.text.v).toSet()
            val ov = if (qt.isEmpty()) 0f else qt.count { it in mt }.toFloat() / qt.size
            val rec = exp(-((now - e.m.updatedAt) / DAY).toFloat() / 120f)
            Hit(e.m, 0.6f * Embedder.cos(qv, e.v).coerceAtLeast(0f) + 0.3f * ov + 0.05f * rec + 0.05f * e.m.importance / 5f)
        }
        val top = scored.filter { it.score >= th }.sortedByDescending { it.score }.take(k)
        if (!withThread) return top
        val ids = top.map { it.m.id }.toMutableSet()
        val extra = mutableListOf<Hit>()
        val all = mems().map { it.m }
        for (h in top.take(3)) all.filter { it.threadId == h.m.threadId && it.status == "active" && it.id !in ids }
            .sortedByDescending { it.createdAt }.take(2).forEach { ids += it.id; extra += Hit(it, h.score * 0.5f) }
        return (top + extra).sortedBy { it.m.createdAt }
    }

    // ---------- journal ----------
    private fun day(ms: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))
    suspend fun logJournal(line: String, ms: Long = System.currentTimeMillis()) {
        val d = day(ms); val ex = dao.autoJournal(d); val cur = ex?.text?.v ?: ""
        if (cur.contains(line)) return
        dao.saveJournal(Journal(id = ex?.id ?: 0, day = d, text = Secret(if (cur.isEmpty()) "• $line" else "$cur\n• $line"), auto = true, updatedAt = ms))
    }

    // ---------- goals ----------
    suspend fun addGoalIfNew(title: String) {
        val v = Embedder.embed(title)
        if (dao.goals().any { Embedder.cos(v, Embedder.embed(it.title.v)) >= 0.7f }) return
        val n = System.currentTimeMillis()
        dao.saveGoal(Goal(title = Secret(title.take(200)), createdAt = n, updatedAt = n))
    }

    // ---------- insights (purely data-derived; every line cites counts/dates) ----------
    suspend fun insights(): List<Section> {
        val now = System.currentTimeMillis()
        val f = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
        val act = allMemories().filter { it.status == "active" }
        val goals = dao.goals()
        val threads = act.groupBy { it.threadId }
        val out = mutableListOf<Section>()
        out += Section("Overview", listOf("${act.size} active memories, ${goals.count { !it.done }} open / ${goals.count { it.done }} completed goals & tasks."))
        out += Section("Forgotten / stalled goals", goals.filter { !it.done && now - it.updatedAt > 14 * DAY }
            .map { "'${it.title.v.take(60)}' — ${(now - it.updatedAt) / DAY} din se update nahi (progress ${it.progress}%)" }
            .ifEmpty { listOf("Koi stalled goal nahi mila (14 din ka threshold).") })
        out += Section("Projects", threads.filter { e -> e.value.any { it.category == "Projects" } }.map { (_, l) ->
            val last = l.maxOf { it.updatedAt }; val first = l.minBy { it.createdAt }
            "'${first.text.v.take(50)}' — ${l.size} linked update(s), last ${f.format(Date(last))}" +
                if (now - last > 21 * DAY) " ⚠ ${(now - last) / DAY} din se mention nahi hua" else ""
        }.ifEmpty { listOf("Abhi koi project memory saved nahi hai.") })
        out += Section("Ideas without follow-up", act.filter { it.category == "Ideas" && (threads[it.threadId]?.size ?: 1) == 1 }
            .take(5).map { "${f.format(Date(it.createdAt))}: ${it.text.v.take(90)}" }.ifEmpty { listOf("Sab ideas ka follow-up hua hai ya koi idea saved nahi.") })
        val rec = act.flatMap { Embedder.tokens(it.text.v).filter { t -> t.length > 3 }.distinct() }
            .groupingBy { it }.eachCount().filter { it.value >= 3 }.entries.sortedByDescending { it.value }.take(6)
        out += Section("Recurring topics", rec.map { "'${it.key}' — ${it.value} memories mein" }.ifEmpty { listOf("Abhi data kam hai (kisi topic ke 3+ mentions nahi).") })
        val ach = Regex("\\b(complete|completed|done|ho gaya|ho gayi|finished|cleared|selected|won|achieved|pass|launched|shipped)\\b", RegexOption.IGNORE_CASE)
        out += Section("Achievements (jaisa aapne kaha)", act.filter { ach.containsMatchIn(it.text.v) }.take(6)
            .map { "${f.format(Date(it.createdAt))}: ${it.text.v.take(90)}" }.ifEmpty { listOf("Koi achievement-type memory nahi mili.") })
        val learn = Regex("\\b(seekh|learn|padh|course|study|tutorial|practice)", RegexOption.IGNORE_CASE)
        val l30 = act.filter { learn.containsMatchIn(it.text.v) && now - it.createdAt < 30 * DAY }
        out += Section("Learning (last 30 din)", listOf(if (l30.isEmpty()) "Pichle 30 din mein learning-related memory nahi mili." else "${l30.size} learning-related memories:") + l30.take(5).map { "• ${it.text.v.take(90)}" })
        return out
    }

    // ---------- backup / export ----------
    suspend fun exportJson(): String {
        fun JSONObject.p(k: String, v: Any) = put(k, v)
        return JSONObject().apply {
            put("app", "MemoirAI"); put("version", 1)
            put("memories", JSONArray(dao.memories().map { JSONObject().p("id", it.id).p("text", it.text.v).p("category", it.category).p("createdAt", it.createdAt).p("updatedAt", it.updatedAt).p("importance", it.importance).p("threadId", it.threadId).p("status", it.status) }))
            put("messages", JSONArray(dao.messages().map { JSONObject().p("id", it.id).p("role", it.role).p("text", it.text.v).p("ts", it.ts) }))
            put("journal", JSONArray(dao.journal().map { JSONObject().p("id", it.id).p("day", it.day).p("text", it.text.v).p("auto", it.auto).p("updatedAt", it.updatedAt) }))
            put("goals", JSONArray(dao.goals().map { JSONObject().p("id", it.id).p("title", it.title.v).p("done", it.done).p("progress", it.progress).p("isTask", it.isTask).p("createdAt", it.createdAt).p("updatedAt", it.updatedAt) }))
        }.toString()
    }

    /** Replaces all current data with the backup (the UI asks for confirmation first). */
    suspend fun importJson(s: String) {
        val o = JSONObject(s)
        require(o.optString("app") == "MemoirAI") { "Ye Memoir AI ka backup nahi hai" }
        fun <T> JSONArray.map(f: (JSONObject) -> T) = (0 until length()).map { f(getJSONObject(it)) }
        val mem = o.getJSONArray("memories").map {
            val t = it.getString("text")
            Memory(it.getLong("id"), Secret(t), it.getString("category"), it.getLong("createdAt"), it.getLong("updatedAt"),
                it.optInt("importance", 3), Secret(Embedder.encode(Embedder.embed(t))), it.optLong("threadId"), it.optString("status", "active"))
        }
        val msg = o.getJSONArray("messages").map { Message(it.getLong("id"), it.getString("role"), Secret(it.getString("text")), it.getLong("ts")) }
        val jr = o.getJSONArray("journal").map { Journal(it.getLong("id"), it.getString("day"), Secret(it.getString("text")), it.getBoolean("auto"), it.getLong("updatedAt")) }
        val gl = o.getJSONArray("goals").map { Goal(it.getLong("id"), Secret(it.getString("title")), it.getBoolean("done"), it.getInt("progress"), it.getBoolean("isTask"), it.getLong("createdAt"), it.getLong("updatedAt")) }
        wipe(); dao.saveMemories(mem); dao.saveMessages(msg); dao.saveJournals(jr); dao.saveGoals(gl); invalidate()
    }

    /** Plain-text export (NOT encrypted — UI warns the user). */
    suspend fun exportMarkdown(): String {
        val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val sb = StringBuilder("# Memoir AI export\n\n## Memories\n")
        allMemories().sortedBy { it.createdAt }.forEach { sb.append("- [${f.format(Date(it.createdAt))}] (${it.category}${if (it.status != "active") ", ${it.status}" else ""}) ${it.text.v}\n") }
        sb.append("\n## Journal\n"); dao.journal().forEach { sb.append("### ${it.day}\n${it.text.v}\n\n") }
        sb.append("## Goals\n"); dao.goals().forEach { sb.append("- [${if (it.done) "x" else " "}] ${it.title.v} (${it.progress}%)\n") }
        return sb.toString()
    }

    suspend fun wipe() { dao.clearMemories(); dao.clearMessages(); dao.clearJournal(); dao.clearGoals(); invalidate() }
}
