package com.memoir.ai.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.memoir.ai.AppVM
import com.memoir.ai.ai.CATEGORIES
import com.memoir.ai.ai.Candidate
import com.memoir.ai.ai.ModelStore
import com.memoir.ai.data.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Dark = darkColorScheme(
    primary = Color(0xFF8AA4FF), onPrimary = Color(0xFF0B1030), secondary = Color(0xFF5EEAD4),
    background = Color(0xFF0E1014), surface = Color(0xFF161A21), surfaceVariant = Color(0xFF1F2430),
    onSurface = Color(0xFFE6E8EE), onSurfaceVariant = Color(0xFFA9B0C0), onBackground = Color(0xFFE6E8EE), error = Color(0xFFFF8A80))

@Composable fun MemoirTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Dark, content = content)

private fun fmt(ms: Long) = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(ms))
private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
@Composable private fun cardColors() = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)

@Composable fun Root(vm: AppVM = viewModel()) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items = listOf("Chat" to Icons.AutoMirrored.Filled.Chat, "Memories" to Icons.Default.Psychology, "Journal" to Icons.Default.Book,
        "Goals" to Icons.Default.Flag, "Settings" to Icons.Default.Settings)
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.toast) { vm.toast?.let { snack.showSnackbar(it); vm.toast = null } }
    Scaffold(snackbarHost = { SnackbarHost(snack) },
        bottomBar = { NavigationBar { items.forEachIndexed { i, (n, ic) ->
            NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, n) }, label = { Text(n, maxLines = 1) }) } } }
    ) { pad -> Box(Modifier.padding(pad).fillMaxSize()) {
        when (tab) {
            0 -> ChatScreen(vm)
            1 -> MemoriesScreen(vm)
            2 -> JournalScreen(vm)
            3 -> GoalsScreen(vm) { tab = 0 }
            else -> SettingsScreen(vm)
        } } }
}

// ------------------------------------------------ CHAT
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ChatScreen(vm: AppVM) {
    var input by remember { mutableStateOf("") }
    var q by remember { mutableStateOf<String?>(null) }
    val list = rememberLazyListState()
    val shown = q?.takeIf { it.isNotBlank() }?.let { s -> vm.messages.filter { it.text.v.contains(s, true) } } ?: vm.messages
    val count = shown.size + (if (vm.streaming != null) 1 else 0) + vm.pending.size
    LaunchedEffect(count, vm.streaming?.length) { if (q == null && count > 0) list.scrollToItem(count - 1) }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input = "$input $it".trim() } }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = {
            if (q != null) OutlinedTextField(q!!, { q = it }, placeholder = { Text("History mein search") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            else Column { Text("Memoir AI", fontWeight = FontWeight.Bold)
                Text(vm.modelStatus + (if (vm.lastStats.isNotEmpty()) " · " + vm.lastStats else ""), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1) }
        }, actions = { IconButton({ q = if (q == null) "" else null }) { Icon(if (q == null) Icons.Default.Search else Icons.Default.Close, "search") } })
        LazyColumn(Modifier.weight(1f), state = list, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (shown.isEmpty() && q == null) item { Text("Namaste! Apni zindagi, plans, ideas — kuch bhi share karo. Main important baatein yaad rakhunga, aur baad mein poochoge to dhoondh ke bataunga.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(shown, key = { it.id }) { Bubble(it.role == "user", it.text.v) }
            vm.streaming?.let { item { Bubble(false, it.ifBlank { vm.statusLine.ifBlank { "⏳ soch raha hoon…" } }) } }
            items(vm.pending) { c -> PendingCard(c, { vm.approve(c) }, { vm.dismiss(c) }) }
        }
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ try { mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")) } catch (e: ActivityNotFoundException) { vm.toast = "Voice input is device par available nahi" } }) { Icon(Icons.Default.Mic, "voice") }
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Kuch bhi share karo…") }, maxLines = 4, shape = RoundedCornerShape(24.dp))
            if (vm.busy) IconButton({ vm.stop() }) { Icon(Icons.Default.Close, "stop", tint = MaterialTheme.colorScheme.error) }
            else IconButton({ if (input.isNotBlank()) { vm.send(input.trim()); input = "" } }) { Icon(Icons.AutoMirrored.Filled.Send, "send", tint = MaterialTheme.colorScheme.primary) }
        }
    }
}

@Composable fun Bubble(user: Boolean, text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Surface(color = if (user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (user) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 310.dp)) { Text(text, Modifier.padding(12.dp, 8.dp)) }
    }
}

@Composable fun PendingCard(c: Candidate, onSave: () -> Unit, onSkip: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3A2A1A))) { Column(Modifier.padding(12.dp)) {
        Text("🔒 Sensitive info — save karun?", fontWeight = FontWeight.Bold)
        Text("“${c.text}”", Modifier.padding(vertical = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onSave) { Text("Haan, save karo") }; OutlinedButton(onSkip) { Text("Nahi") } }
    } }
}

// ------------------------------------------------ MEMORIES
@Composable fun MemoriesScreen(vm: AppVM) {
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<String?>(null) }
    var old by remember { mutableStateOf(false) }
    var mems by remember { mutableStateOf(listOf<Memory>()) }
    var edit by remember { mutableStateOf<Memory?>(null) }
    var adding by remember { mutableStateOf(false) }
    var thread by remember { mutableStateOf<List<Memory>?>(null) }
    LaunchedEffect(q, cat, old, vm.version) { mems = vm.queryMemories(q, cat, old) }
    Scaffold(containerColor = Color.Transparent, contentWindowInsets = WindowInsets(0),
        floatingActionButton = { FloatingActionButton({ adding = true }) { Icon(Icons.Default.Add, "add") } }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            Text("Memory Library", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 12.dp))
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) },
                placeholder = { Text("Poocho: \"mere goals kya hain?\", \"last month kya discuss kiya\"") })
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                item { FilterChip(cat == null, { cat = null }, { Text("All") }) }
                items(CATEGORIES) { c -> FilterChip(cat == c, { cat = if (cat == c) null else c }, { Text(c) }) }
                item { FilterChip(old, { old = !old }, { Text("Outdated") }) }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                if (mems.isEmpty()) item { Text("Koi memory nahi mili.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(mems, key = { it.id }) { m ->
                    val outdated = m.status != "active"
                    Card(colors = cardColors()) { Column(Modifier.padding(12.dp)) {
                        Row { Text(m.category, color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                            Text(fmt(m.createdAt) + if (outdated) " · outdated" else "", style = MaterialTheme.typography.labelSmall) }
                        Text(m.text.v, Modifier.padding(vertical = 6.dp), textDecoration = if (outdated) TextDecoration.LineThrough else null,
                            color = if (outdated) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                        Row { TextButton({ edit = m }) { Text("Edit") }; TextButton({ vm.deleteMemory(m) }) { Text("Delete") }
                            TextButton({ vm.loadThread(m.threadId) { thread = it } }) { Text("History") }
                            if (outdated) TextButton({ vm.setStatus(m, "active") }) { Text("Restore") } }
                    } }
                }
            }
        }
    }
    if (adding) MemoryDialog(null, "Naya memory", { t, c -> vm.addMemory(t, c); adding = false }) { adding = false }
    edit?.let { m -> MemoryDialog(m, "Edit memory", { t, c -> vm.editMemory(m, t, c); edit = null }) { edit = null } }
    thread?.let { l -> AlertDialog(onDismissRequest = { thread = null }, confirmButton = { TextButton({ thread = null }) { Text("Close") } },
        title = { Text("Topic history (${l.size})") }, text = { LazyColumn { items(l) { Text("• ${fmt(it.createdAt)}: ${it.text.v}\n", style = MaterialTheme.typography.bodyMedium) } } }) }
}

@Composable fun MemoryDialog(m: Memory?, title: String, onSave: (String, String) -> Unit, onDismiss: () -> Unit) {
    var t by remember { mutableStateOf(m?.text?.v ?: "") }
    var c by remember { mutableStateOf(m?.category ?: CATEGORIES[0]) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        confirmButton = { TextButton({ if (t.isNotBlank()) onSave(t.trim(), c) }) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
        text = { Column { OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth(), minLines = 3)
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(CATEGORIES) { x -> FilterChip(c == x, { c = x }, { Text(x) }) } } } })
}

// ------------------------------------------------ JOURNAL + INSIGHTS
@Composable fun JournalScreen(vm: AppVM) {
    var sub by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf<Journal?>(null) }
    var adding by remember { mutableStateOf(false) }
    var sections by remember { mutableStateOf(listOf<Section>()) }
    LaunchedEffect(vm.version, sub) { if (sub == 1) sections = vm.repo.insights() }
    Scaffold(containerColor = Color.Transparent, contentWindowInsets = WindowInsets(0),
        floatingActionButton = { if (sub == 0) FloatingActionButton({ adding = true }) { Icon(Icons.Default.Add, "add") } }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            TabRow(sub, containerColor = Color.Transparent) { Tab(sub == 0, { sub = 0 }, text = { Text("Timeline") }); Tab(sub == 1, { sub = 1 }, text = { Text("Insights") }) }
            if (sub == 0) {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), singleLine = true, placeholder = { Text("Timeline search (text ya 2026-11)") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                val groups = vm.journal.filter { q.isBlank() || it.text.v.contains(q, true) || it.day.contains(q) }.groupBy { it.day }.toList()
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                    if (groups.isEmpty()) item { Text("Abhi journal khaali hai. Chat mein baat karo ya manual entry add karo.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    groups.forEach { (day, es) ->
                        item { Text(day, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp)) }
                        items(es, key = { it.id }) { j -> Card(colors = cardColors()) { Column(Modifier.padding(12.dp)) {
                            Text(if (j.auto) "Auto journal" else "Manual", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            Text(j.text.v, Modifier.padding(vertical = 4.dp))
                            Row { TextButton({ edit = j }) { Text("Edit") }; TextButton({ vm.deleteJournal(j) }) { Text("Delete") } }
                        } } }
                    }
                }
            } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 10.dp)) {
                items(sections) { s -> Card(colors = cardColors()) { Column(Modifier.padding(12.dp)) {
                    Text(s.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    s.lines.forEach { Text(it, Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodyMedium) } } } }
            }
        }
    }
    if (adding) JournalDialog(null, { adding = false }) { d, t -> vm.saveJournal(0, d, t, false); adding = false }
    edit?.let { j -> JournalDialog(j, { edit = null }) { d, t -> vm.saveJournal(j.id, d, t, j.auto); edit = null } }
}

@Composable fun JournalDialog(j: Journal?, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var d by remember { mutableStateOf(j?.day ?: today()) }
    var t by remember { mutableStateOf(j?.text?.v ?: "") }
    val ok = Regex("\\d{4}-\\d{2}-\\d{2}").matches(d) && t.isNotBlank()
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Journal entry") },
        confirmButton = { TextButton({ if (ok) onSave(d, t.trim()) }, enabled = ok) { Text("Save") } },
        text = { Column { OutlinedTextField(d, { d = it }, label = { Text("Date (yyyy-MM-dd)") }, singleLine = true)
            OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth().padding(top = 8.dp), minLines = 4) } })
}

// ------------------------------------------------ GOALS
@Composable fun GoalsScreen(vm: AppVM, toChat: () -> Unit) {
    var sub by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf(false) }
    var related by remember { mutableStateOf(mapOf<Long, List<String>>()) }
    LaunchedEffect(vm.goals) { related = vm.goals.filter { !it.done }.associate { g ->
        g.id to vm.repo.search(g.title.v, 3, withThread = false).map { it.m.text.v }.filter { it != g.title.v }.take(2).map { it.take(90) } } }
    val shown = vm.goals.filter { it.done == (sub == 1) }
    Scaffold(containerColor = Color.Transparent, contentWindowInsets = WindowInsets(0),
        floatingActionButton = { FloatingActionButton({ adding = true }) { Icon(Icons.Default.Add, "add") } }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            TabRow(sub, containerColor = Color.Transparent) { Tab(sub == 0, { sub = 0 }, text = { Text("Open (${vm.goals.count { !it.done }})") }); Tab(sub == 1, { sub = 1 }, text = { Text("Done (${vm.goals.count { it.done }})") }) }
            if (sub == 0) OutlinedButton({ vm.ask("Mere open goals aur saved memories ke basis par mujhe next steps suggest karo."); toChat() }, Modifier.padding(vertical = 8.dp)) { Text("💡 Suggestions maango") }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                if (shown.isEmpty()) item { Text("Yahan abhi kuch nahi.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)) }
                items(shown, key = { it.id }) { g ->
                    var p by remember(g.id, g.progress) { mutableFloatStateOf(g.progress / 100f) }
                    Card(colors = cardColors()) { Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(g.done, { vm.saveGoal(g.copy(done = it, progress = if (it) 100 else g.progress.coerceAtMost(99))) })
                            Column(Modifier.weight(1f)) { Text(g.title.v, textDecoration = if (g.done) TextDecoration.LineThrough else null)
                                Text((if (g.isTask) "Task" else "Goal") + " · ${fmt(g.createdAt)}", style = MaterialTheme.typography.labelSmall) }
                            IconButton({ vm.deleteGoal(g) }) { Icon(Icons.Default.Delete, "delete") } }
                        if (!g.done) { Slider(p, { p = it }, onValueChangeFinished = { vm.saveGoal(g.copy(progress = (p * 100).toInt())) }); Text("${(p * 100).toInt()}% complete", style = MaterialTheme.typography.labelSmall)
                            related[g.id]?.forEach { Text("↳ related: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
                    } }
                }
            }
        }
    }
    if (adding) { var t by remember { mutableStateOf("") }; var task by remember { mutableStateOf(false) }
        AlertDialog(onDismissRequest = { adding = false }, title = { Text("Naya goal / task") },
            confirmButton = { TextButton({ if (t.isNotBlank()) { vm.addGoal(t.trim(), task); adding = false } }) { Text("Add") } },
            text = { Column { OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth(), minLines = 2)
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(task, { task = it }); Text("  Ye ek task hai (goal nahi)") } } }) }
}

// ------------------------------------------------ SETTINGS
@Composable fun SettingsScreen(vm: AppVM) {
    var passFor by remember { mutableStateOf<String?>(null) }
    var uri by remember { mutableStateOf<android.net.Uri?>(null) }
    var confirmWipe by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importModel) }
    val expB = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { if (it != null) { uri = it; passFor = "export" } }
    val impB = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { if (it != null) { uri = it; passFor = "import" } }
    val expM = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { it?.let(vm::exportMarkdown) }
    LazyColumn(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
        item { Text("Settings", style = MaterialTheme.typography.titleLarge) }
        item { Card(colors = cardColors()) { Column(Modifier.padding(12.dp)) {
            Text("On-device AI model (llama.cpp)", fontWeight = FontWeight.Bold); Text(vm.modelStatus, style = MaterialTheme.typography.bodySmall)
            Text(vm.ramInfo, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp))
            Text("Memory save/search model ke bina bhi offline kaam karta hai. Model sirf natural Hinglish baatcheet ke liye hai. 3–4 GB RAM (Redmi Note 8) → Qwen 0.5B ya Llama 1B; 6 GB+ → 1.5B–3B (Q4). Purane phones par pehla jawab aane mein 10–60 sec lag sakte hain.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("chatml", "llama3", "gemma").forEach { t -> FilterChip(vm.template == t, { vm.updateTemplate(t) }, { Text(t) }) } }
            vm.downloading?.let { Text("Downloading ${it}… ${(vm.progress * 100).toInt()}%", Modifier.padding(top = 6.dp)); LinearProgressIndicator(progress = { vm.progress }, Modifier.fillMaxWidth()) }
            ModelStore.presets.forEach { p -> Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${p.name}\n~${p.sizeMb} MB", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton({ vm.download(p) }, enabled = vm.downloading == null) { Text("Download") } } }
            OutlinedButton({ pick.launch(arrayOf("*/*")) }) { Text("Import .gguf file") }
        } } }
        items(vm.models) { f -> Card(colors = cardColors()) { Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${f.name}\n${f.length() / 1_000_000} MB", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            val active = vm.loadedPath == f.absolutePath
            TextButton({ vm.loadModel(f.absolutePath) }, enabled = !vm.loading && !active) { Text(if (active) "● Loaded" else "Load") }; TextButton({ vm.deleteModel(f) }, enabled = !vm.loading) { Text("Delete") } } } }
        item { if (vm.loadedPath != null) OutlinedButton({ vm.unloadModel() }) { Text("Unload model (RAM free karo)") } }
        item { Card(colors = cardColors()) { Column(Modifier.padding(12.dp)) {
            Text("AI self-test", fontWeight = FontWeight.Bold)
            Text("Model ko ek chhota sawaal bhejta hai (memory ke bina) — batata hai model sach mein jawab de raha hai ya nahi, aur kitni speed se.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
            Button({ vm.testModel() }, enabled = vm.loadedPath != null && !vm.loading) { Text("Test AI") }
            vm.testResult?.let { Text(it, Modifier.padding(top = 8.dp)) }
        } } }
        item { Card(colors = cardColors()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Auto-save memories", fontWeight = FontWeight.Bold); Text("Sensitive info hamesha pehle permission maangta hai.", style = MaterialTheme.typography.bodySmall) }
            Switch(vm.autoSave, vm::updateAutoSave) } } }
        item { Card(colors = cardColors()) { Column(Modifier.padding(12.dp)) {
            Text("Backup & export", fontWeight = FontWeight.Bold)
            Text("Backup passphrase se AES-256 encrypted hota hai. Passphrase bhool gaye to restore nahi hoga.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button({ expB.launch("memoir-backup.memoir") }) { Text("Backup") }
                OutlinedButton({ impB.launch(arrayOf("*/*")) }) { Text("Restore") } }
            TextButton({ expM.launch("memoir-export.md") }) { Text("Export Markdown (unencrypted)") }
        } } }
        item { Card(colors = cardColors()) { Column(Modifier.padding(12.dp)) {
            Text("Privacy", fontWeight = FontWeight.Bold)
            Text("Sab data sirf is device par, Android Keystore-backed AES-256 se encrypted. Internet sirf model download ke liye.", style = MaterialTheme.typography.bodySmall)
            TextButton({ confirmWipe = true }) { Text("Saara data delete karo", color = MaterialTheme.colorScheme.error) } } } }
    }
    passFor?.let { mode -> var pw by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { passFor = null }, title = { Text(if (mode == "export") "Backup passphrase set karo" else "Backup passphrase") },
            text = { OutlinedTextField(pw, { pw = it }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()) },
            confirmButton = { TextButton({ if (pw.length >= 6) { uri?.let { u -> if (mode == "export") vm.exportBackup(u, pw) else vm.importBackup(u, pw) }; passFor = null } }, enabled = pw.length >= 6) {
                Text(if (mode == "export") "Backup" else "Restore (current data replace hoga)") } }) }
    if (confirmWipe) AlertDialog(onDismissRequest = { confirmWipe = false }, title = { Text("Sab kuch delete?") }, text = { Text("Memories, chat, journal, goals — sab permanently delete hoga.") },
        confirmButton = { TextButton({ vm.wipe(); confirmWipe = false }) { Text("Delete") } }, dismissButton = { TextButton({ confirmWipe = false }) { Text("Cancel") } })
}
