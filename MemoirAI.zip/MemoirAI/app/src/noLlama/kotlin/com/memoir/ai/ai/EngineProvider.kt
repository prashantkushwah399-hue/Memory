package com.memoir.ai.ai

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow

/** Used only when built with -PuseLlama=false (no native code): offline memory mode. */
class StubEngine : LlmEngine {
    override val isLoaded = false
    override val contextSize = 2048
    override suspend fun load(path: String) =
        Result.failure<Unit>(IllegalStateException("Is build mein llama.cpp disabled hai (-PuseLlama=false). Normal build karo."))
    override fun generate(prompt: String): Flow<String> = emptyFlow()
    override suspend fun unload() {}
}
object EngineProvider { fun create(): LlmEngine = StubEngine() }
