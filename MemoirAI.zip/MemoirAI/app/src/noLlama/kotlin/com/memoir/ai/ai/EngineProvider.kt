package com.memoir.ai.ai

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow

/** Default build: no native LLM. App runs in "offline memory mode" (retrieval-based replies). */
class StubEngine : LlmEngine {
    override val isLoaded = false
    override suspend fun load(path: String) =
        Result.failure<Unit>(IllegalStateException("llama.cpp build mein nahi hai. README ka 'Enable the on-device LLM' section dekho."))
    override fun generate(prompt: String): Flow<String> = emptyFlow()
    override suspend fun unload() {}
}
object EngineProvider { fun create(): LlmEngine = StubEngine() }
