@rem Gradle wrapper launcher (Windows).
@rem If gradle\wrapper\gradle-wrapper.jar is missing it is fetched once from the official Gradle repository.
@if "%DEBUG%"=="" @echo off
setlocal
set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_HOME=%DIRNAME%
set JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
set GRADLE_TAG=v8.9.0

if exist "%JAR%" goto haveJar
echo gradle-wrapper.jar missing - downloading... 1>&2
if not exist "%APP_HOME%gradle\wrapper" mkdir "%APP_HOME%gradle\wrapper"
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/gradle/gradle/%GRADLE_TAG%/gradle/wrapper/gradle-wrapper.jar' -OutFile '%JAR%'"
if not exist "%JAR%" (
  echo ERROR: download failed. Run 'gradle wrapper --gradle-version 8.9' or open the project in Android Studio. 1>&2
  exit /b 1
)
:haveJar

if defined JAVA_HOME goto findJavaFromJavaHome
set JAVA_EXE=java.exe
goto execute
:findJavaFromJavaHome
set JAVA_EXE=%JAVA_HOME%\bin\java.exe
if exist "%JAVA_EXE%" goto execute
echo ERROR: JAVA_HOME is set to an invalid directory: %JAVA_HOME% 1>&2
exit /b 1

:execute
"%JAVA_EXE%" -Xmx64m -Xms64m %JAVA_OPTS% %GRADLE_OPTS% "-Dorg.gradle.appname=gradlew" -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
set EXITCODE=%ERRORLEVEL%
endlocal & exit /b %EXITCODE%
