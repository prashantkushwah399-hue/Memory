pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name = "MemoirAI"
include(":app")
// Optional llama.cpp module (see README, step "Enable the on-device LLM")
if (file("llama").exists()) include(":llama")
